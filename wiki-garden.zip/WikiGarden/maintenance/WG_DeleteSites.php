<?php

//define( 'SCRIPT_ONLY', true );
$_SERVER['SERVER_NAME'] = '';
$IP = realpath( dirname( __FILE__ ) . '/../../..' );

require_once( "$IP/maintenance/Maintenance.php" );

class WGDeleteSites extends Maintenance {

	function execute() {
		$allSites = WGSite::getAllForDeletion();
		$numSites = count( $allSites );

		print "Deleting sites ($numSites altogether)... please make sure that you are logged in as root...\n";

		foreach ( $allSites as $i => $site ) {
			$site->loadSettings();
			$site->setSiteStatistics();
			if ( $site->total_edits > 2000 ) {
				print "Skipping {$site->url} ({$site->total_edits} edits). ";
				continue;
			}
			print "Deleting \"{$site->name}\" ({$site->url}, {$site->total_edits} edits) - hit Ctrl-C to cancel...\n";
			sleep( 5 );
			//sleep( 10 );
			$num_deleted_files = $site->fullyDelete();
			if ($num_deleted_files > 0) {
				print "Deleted $num_deleted_files files.\n";
			}
		}
	}
}

$maintClass = "WGDeleteSites";
require_once( RUN_MAINTENANCE_IF_MAIN );
