<?php
/**
 *
 * @author Yaron Koren
 */

class WGManageSite extends WGSuperAdminSpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct( 'ManageSite' );
	}

	function printPage( $query ) {
		global $wgWikiGardenServiceSettings;

		$out = $this->getOutput();
		$request = $this->getRequest();
		$skin = $this->getSkin();

		$text = "";
		if ( $query == '' ) {
			$text = "<p>URL should be Special:ManageSite/<em>site-name</em>.</p>\n";
			$out->addHTML( $text );
			return;
		}

		$site = WGSite::findByURL( $query );
		if ( is_null( $site ) ) {
			$text = "<p>Could not find a site at the subdomain '$query'.</p>\n";
			$out->addHTML( $text );
			return;
		}

		$out->setPageTitle( wfMessage( 'managesite' )->text() . ': ' . $site->name );

		if ( $request->getCheck( 'service_level' ) ) {
			$site->service_level = $request->getVal( 'service_level' );
			// Why are editing and registration policies
			// specifically settable here? In order to handle
			// "zombie" wikis beset by spam.
			$site->editing_policy_id = $request->getVal( 'editing_policy_id' );
			$site->registration_policy_id = $request->getVal( 'registration_policy_id' );
			$site->virtual_domain = $request->getVal( 'virtual_domain' );
			$site->custom_skin = $request->getVal( 'custom_skin' );
			$site->delete_this = $request->getCheck( 'delete' ) ? '1' : '0';
			$site->saveSuperAdminSettings();
			$text .= '<div class="successbox">' . wfMessage( 'sitesettings-updated' )->text() . "</div>\n";
		}

		$site_url = $site->getURL();
		$service_level_label = wfMessage( 'servicelevel' )->text();
		$editing_policy_label = wfMessage( 'sitesettings-editingpolicy' )->text();
		$registration_policy_label = wfMessage( 'sitesettings-registrationpolicy' )->text();
		$created_at_str = date( 'n/j/y', $site->created_at );

		$owner = $site->getOwner();
		$ownerStr = $skin->link( $owner->getUserPage(),
			htmlspecialchars( $owner->getName() ) );
		$emailAddress = $owner->getEmail();
		$site->setLastUpdatedDate();
		$site->setSiteStatistics();
		$mb_used = $site->getMegabytesUsed();
		$text .=<<<END
	<p>URL: <a href="$site_url">$site_url</a></p>
	<p>Created on $created_at_str by $ownerStr; last updated on {$site->last_updated_str}.</p>
	<p>Main administrator: {$site->getMainAdmin()}, $emailAddress</p>
	<p>Views: {$site->total_views}; edits: {$site->total_edits}; pages: {$site->total_pages}; users: {$site->num_users}.</p>
	<p>Megabytes used: $mb_used.</p>
	<fieldset>
	<legend>Settings</legend>
	<form action="" method="post">
	<p>$service_level_label: <select name="service_level">

END;
		foreach ( $wgWikiGardenServiceSettings as $name => $settings ) {
			$optionAttrs = array( 'value' => $name );
			if ( $site->service_level == $name ) {
				$optionAttrs['selected'] = true;
			}
			$text .= Html::element( 'option', $optionAttrs, $name );
		}
		$text .=<<<END
	</select></p>
	<p>$editing_policy_label: <select name="editing_policy_id">

END;
		// @TODO - this should be defined elsewhere.
		$editingPolicies = array(
			'2' => 'Open',
			'3' => 'Closed',
			'4' => 'Very closed',
		);
		foreach ( $editingPolicies as $id => $name ) {
			$optionAttrs = array( 'value' => $id );
			if ( $site->editing_policy_id == $id ) {
				$optionAttrs['selected'] = true;
			}
			$text .= Html::element( 'option', $optionAttrs, $name );
		}
		$text .=<<<END
	</select></p>
	<p>$registration_policy_label: <select name="registration_policy_id">

END;
		// @TODO - this should be defined elsewhere.
		$registrationPolicies = array(
			'1' => 'Open',
			'2' => 'OpenID only',
			'3' => 'Closed',
		);
		foreach ( $registrationPolicies as $id => $name ) {
			$optionAttrs = array( 'value' => $id );
			if ( $site->registration_policy_id == $id ) {
				$optionAttrs['selected'] = true;
			}
			$text .= Html::element( 'option', $optionAttrs, $name );
		}
		$text .=<<<END
	</select></p>

END;
		$text .= "\t" . Html::rawElement( 'p', null,
			wfMessage( 'wg_managesite_virtualdomain' )->text() . Html::input( 'virtual_domain', $site->virtual_domain, 'text' ) ) . "\n";
		$text .= "\t" . Html::rawElement( 'p', null,
			wfMessage( 'wg_managesite_customskin' )->text() . Html::input( 'custom_skin', $site->custom_skin, 'text' ) ) . "\n";
		$deletion_label = wfMessage( 'wg_managesite_willbedeleted' )->text();
		$dt_checked_str = $site->delete_this ? 'checked="checked"' : '';
		$text .=<<<END
	<p><input type="checkbox" name="delete" $dt_checked_str/> $deletion_label</p>
	<p><input type="submit" value="Change settings" /></p>
	</form>
	</fieldset>

END;
		$out->addHTML( $text );
	}
}
