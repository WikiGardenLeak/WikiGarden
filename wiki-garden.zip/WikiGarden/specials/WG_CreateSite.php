<?php
/**
 * A special page to let the user create a site.
 *
 * @author Yaron Koren
 */

class WGCreateSite extends WGMainSiteSpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct( 'CreateSite' );
	}

	function printPage( $query ) {
		global $wgShowExceptionDetails, $wgWikiGardenDomain;

		// initialize variables
		$wgShowExceptionDetails = true;
		$user = $this->getUser();
		$skin = $this->getSkin();
		$out = $this->getOutput();
		$request = $this->getRequest();
		$error_header = "";
		$errors = array();
		$site_name = $url = $username = "";
	
		// Must be logged in to create a site.
		if ( $user->isAnon() ) {
			// @TODO - there's an easier way to do this.
			$out->setPageTitle( wfMessage( 'watchnologin' )->text() );
			$specialTitle = SpecialPage::getTitleFor( 'CreateSite' );
			$llink = $skin->link( SpecialPage::getTitleFor( 'Userlogin' ), wfMessage( 'loginreqlink' )->parse(), array(), 'returnto=' . $specialTitle->getPrefixedUrl() );
			$out->addHtml( wfMessage( 'wg-createsite-anontext', $llink )->text() );
			return;
		}

		// User must have 'createsite' permission.
		if ( !$user->isAllowed( 'createsite' ) ) {
			$this->setHeaders();
			$out->permissionRequired( 'createsite' );
			return;
		}

		// User must have their email authenticated.
		if ( !$user->getEmailAuthenticationTimestamp()) {
			global $wgSitename;
			$out->setPageTitle( wfMessage( 'wg_emailauthrequired' )->text() );
			$out->addHtml( "<p>" . wfMessage( 'wg_emailauthrequireddesc', $wgSitename )->text() . "</p>" );
			return;
		 }

		$site_created = false;

		if ( $request->getCheck( 'create' ) ) {
			$url = strtolower( $request->getVal( 'url' ) );
			$site_name = $request->getVal( 'site_name' );
			$username = $request->getVal( 'username' );
			$password = $request->getVal( 'password' );
			// Check all inputs.
			if ( strlen( $url ) < 3 ) {
				$errors['url'] = wfMessage( 'wg-createsite-shortsubdomainerror' )->text();
			} elseif ( preg_match( '/[^A-Za-z0-9\-]/', $url ) ) {
				$errors['url'] = wfMessage( 'wg-createsite-urlinvalidcharserror' )->text();
			} else {
				if ( $site = WGSite::findByURL( $url ) ) {
					$errors['url'] = wfMessage( 'wg-createsite-urltakenerror' )->text();
				}
			}
			if ( $site_name == '' ) {
				$errors['site_name'] = wfMessage( 'wg-createsite-blanksitenameerror' )->text();
			}

			if ( strlen( $username ) < 1 ) {
				$errors['username'] = wfMessage( 'wg-createsite-blankusernameerror' )->text();
			}
			if ( strlen ($password ) < 5) {
				$errors['password'] = wfMessage( 'wg-createsite-shortpassworderror' )->text();
			}

			if ( count( $errors ) > 0 ) {
				$error_header = '<div class="errorbox">' . wfMessage( 'wg-createsite-errors' )->text() . "</div>\n";
			} else {
				// Switch to this database for user actions.
				global $wgDBserver, $wgDBuser, $wgDBpassword, $wgDBname, $wgDBtype;
				global $wgDebugDumpSql, $wgDBservers, $wgLoadBalancer, $wgMasterWaitTimeout;
				global $wgWikiGardenDBNamePrefix;

				$wgDBname = $wgWikiGardenDBNamePrefix . $url;
				WGUtils::createDatabase();
				$wgDBservers = array( array(
					'host' => $wgDBserver,
					'user' => $wgDBuser,
					'password' => $wgDBpassword,
					'dbname' => $wgDBname,
					'type' => $wgDBtype,
					'load' => 1,
					'flags' => ( $wgDebugDumpSql ? DBO_DEBUG : 0 ) | DBO_DEFAULT
				) );

				$wgLoadBalancer = new StubObject( 'wgLoadBalancer', 'LoadBalancer',
					array( $wgDBservers, false, $wgMasterWaitTimeout, true ) );

				WGUtils::createAdminUser( $username, $password, $user->getEmail() );
				global $wgWikiGardenSubdomain;
				WGSite::create( $url, $site_name, $wgWikiGardenSubdomain, $user->getId(), $wgDBname );

				$text = "	<p>" . wfMessage( 'wg-createsite-sitecreated', $site_name, "http://$url.$wgWikiGardenDomain" )->parse() . "</p>\n";
				$site_created = true;
			}
		}

		if ( !$site_created ) {
			$site_name_label = wfMessage( 'wg-createsite-sitename' )->text();
			$url_label = wfMessage( 'wg-createsite-url' )->text();
			$login_information_label = wfMessage( 'wg-createsite-logininformation' )->text();
			$username_label = wfMessage( 'wg-createsite-username' )->text();
			$password_label = wfMessage( 'wg-createsite-password' )->text();
			$site_name_error = array_key_exists( 'site_name', $errors) ? '<span style="color: red;">' . $errors['site_name'] . '</span>' : "";
			$url_error = array_key_exists( 'url', $errors ) ? '<span style="color: red;">' . $errors['url'] . '</span>' : "";
			$username_error = array_key_exists( 'username', $errors ) ? '<span style="color: red;">' . $errors['username'] . '</span>' : "";
			$password_error = array_key_exists( 'password', $errors ) ? '<span style="color: red;">' . $errors['password'] . '</span>' : "";
			$create_label = wfMessage( 'create' )->text();
		
			$text =<<<END
	$error_header
	<form action="" method="post">
	<p><label>$url_label <input type="text" name="url" value="$url" />.$wgWikiGardenDomain</label> $url_error</p> 
	<p><label>$site_name_label <input type="text" name="site_name" value="$site_name" /></label> $site_name_error</p>
	<fieldset>
	<legend>$login_information_label</legend>
	<p><label>$username_label <input type="text" name="username" value="$username" /></label> $username_error</p>
	<p><label>$password_label <input type="password" name="password" /></label> $password_error</p>
	</fieldset>
	<input type="Submit" name="create" value="$create_label">
	</form>

END;
		}

		$out->addHTML( $text );
	}

}
