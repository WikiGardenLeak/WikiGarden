<?php
/**
 * @author Yaron Koren
 */

class WGServiceLevel extends SpecialPage {

	/**
	 * Constructor
	 */
	function WGServiceLevel() {
		parent::__construct( 'ServiceLevel' );
	}


	function handlePayPalValues( $site ) {
		global $wgRequest, $wgWikiGardenServiceSettings;
		global $wgWikiGardenPayPalIdentityToken;

		$req = 'cmd=_notify-synch';
		$transaction_id = $wgRequest->getVal( 'tx' );
		$transaction_id = urlencode( stripslashes( $transaction_id ) );
		$req .= "&tx=$transaction_id";
		$req .= "&at=$wgWikiGardenPayPalIdentityToken";

		// post back to PayPal system to validate
		$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
		$fp = fsockopen('www.paypal.com', 80, $errno, $errstr, 30);

		$valid_transaction = false;
		if ( ! $fp ) return;

		fputs ( $fp, $header . $req);
		while ( !feof( $fp ) ) {
			$res = fgets( $fp, 1024 );
			$res = trim( urldecode( $res ) );
			if ( $res == "SUCCESS" ) {
				$valid_transaction = true;
			}
			if ( strstr( $res, "custom=" ) ) {
				$custom_value = substr( $res, 7 );
				$custom_vals = explode('|', $custom_value);
				if ( is_array( $custom_vals ) ) {
					$service_name = $custom_vals[0];
				} else {
					$service_name = $custom_value;
				}
			}
		} // end while
		fclose ($fp);

		if ( ! $valid_transaction ) return;
		foreach ( $wgWikiGardenServiceSettings as $id => $settings ) {
			if ( $settings['name'] == $service_name ) {
				$site->service_level = $id;
				$site->saveSettingsForTab( 'service level' );
			}
		}
		return $service_name;
	}

	function payPalButtonHTML( $site, $plan_amount, $plan_name ) {
		global $wgSitename;
		global $wgWikiGardenCurrency, $wgWikiGardenSubscriptionsEmail;
		global $wgWikiGardenPayPalIPNURL;

		$inv = rand( 45660, 942345677 );
		$pay_pal_url = 'https://www.paypal.com/cgi-bin/webscr';
		$site_url = $site->getURL();
		$subdomain = $site->url;

		$text =<<<END
	<form action="$pay_pal_url" method="post" name="ppform">
	<input type="submit" value="Upgrade" />
	<input type="hidden" name="business" value="$wgWikiGardenSubscriptionsEmail" />
	<input type="hidden" name="cmd" value="_xclick-subscriptions"/>
	<input type="hidden" name="a3" value="$plan_amount"/>
	<input type="hidden" name="p3" value="1"/>
	<input type="hidden" name="t3" value="M"/>
	<input type="hidden" name="custom" value="$plan_name|$inv"/>
	<input type="hidden" name="no_note" value="1"/>
	<input type="hidden" name="no_shipping" value="2"/>
	<input type="hidden" name="src" value="1"/>
	<input type="hidden" name="return" value="$site_url/Special:ServiceLevel"/>
	<input type="hidden" name="currency_code" value="$wgWikiGardenCurrency"/>
	<input type="hidden" name="item_name" value="$wgSitename $plan_name Monthly Subscription for {$site->name} ($site_url)"/>
	<input type="hidden" name="item_number" value="$subdomain"/>

END;
		if ( !is_null( $wgWikiGardenPayPalIPNURL ) ) {
			$text .=<<<END
	<input type="hidden" name="notify_url" value="$wgWikiGardenPayPalIPNURL"/>

END;
		}
		$text .=<<<END
	</form>

END;
		return $text;
	}

	function execute( $query ) {
		global $wgUser, $wgOut, $wgRequest, $wgSitename;
		global $wgWikiGardenSubdomain;
		global $wgWikiGardenServiceLevelsURL;

		$this->setHeaders();

		// Permission check
		if( !$wgUser->isAllowed( 'administerwikis' ) ) {
			$wgOut->permissionRequired( 'administerwikis' );
			return;
		}

		// Add CSS
		$wgOut->addModules( 'ext.wikigarden.main' );

		// Initialize variables
		$text = "";
		$site = WGSite::findByURL( $wgWikiGardenSubdomain );

		if ( $wgRequest->getCheck( 'tx' ) ) {
			$this->handlePayPalValues( $site );
		}

		$current_level_text = wfMsg( 'wg_servicelevel_currentlevel', $site->getServiceLevelName() );
		if ( !is_null( $wgWikiGardenServiceLevelsURL ) ) {
			$current_level_text .= ' (<a href="' . $wgWikiGardenServiceLevelsURL . '">' . wfMsg( 'wg_servicelevel_review' ) . '</a>)';
		}
		$text .= "	<p>$current_level_text</p>\n";
		if ( $site->requiresSubscription() ) {
			global $wgWikiGardenSubscriptionsEmail;
			$review_or_cancel_text = wfMsg( 'wg_servicelevel_revieworcancel', "https://www.paypal.com/cgi-bin/webscr?cmd=_subscr-find&alias=$wgWikiGardenSubscriptionsEmail" );
			$text .= "	<p>$review_or_cancel_text</p>\n";
		} else {
			$options_header = wfMsg( 'wg_servicelevel_optionsheader' );
			$text .=<<<END
	<br />
	<p>$options_header</p>
	<table class="payment_options">

END;
			global $wgWikiGardenServiceSettings;
			foreach ( $wgWikiGardenServiceSettings as $id => $settings ) {
				$monthly_rate = $settings['monthly rate'];
				if ( $monthly_rate == 0 ) continue;
				$subscription_name = $settings['name'] . " account monthly subscription ($". $monthly_rate . ")";
				$pay_pal_button = $this->payPalButtonHTML( $site, $monthly_rate, $settings['name'] );
				$text .=<<<END
		<tr>
		<td>
		$subscription_name
		</td>
		<td>
		$pay_pal_button
		</td>
		</tr>

END;
		}
			$text .= "\t</table>\n";
			$text .= "\t<p>" . wfMsg( 'wg_servicelevel_paymentdesc', $wgWikiGardenSitename ) . "</p>\n";
		} // end if($site->...

		$wgOut->addHTML( $text );
	}
}
