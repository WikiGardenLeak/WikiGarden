<?php
/**
 *
 * @author Yaron Koren
 */

class WGEmailAdmins extends WGSuperAdminSpecialPage {

	function __construct() {
		parent::__construct('EmailAdmins');
	}

	function fromString() {
		$user = $this->getUser();
		return $user->getName() . " <{$user->getEmail()}>";
	}

	/**
	 * "toString" here means "the text that will show up in the To: line
	 * of the email". It's confusing!
	 */
	static function toString() {
		global $wgSitename, $wgWikiGardenAnnouncementsEmail;
		return wfMessage( 'wg_emailadmins_siteadmins', $wgSitename )->text() . " <$wgWikiGardenAnnouncementsEmail>";
	}

	static function recipientsString( $offset = null, $length = null ) {
		$email_addresses = array();
		$sites = WGSite::getAll();
		foreach ( $sites as $site ) {
			// Set email address to be the array key,
			// to avoid repeated values.
			$email_addresses[$site->getOwner()->getEmail()] = true;
		}
		ksort( $email_addresses );
		// Remove the 'null email address' value, if it's there.
		unset( $email_addresses[''] );
		if ( !is_null( $offset) && !is_null( $length ) ) {
			if ( $offset > count( $email_addresses ) ) {
				return null;
			}
			$email_addresses = array_slice( $email_addresses, $offset, $length );
		}
		$recipients_str = implode(', ', array_keys( $email_addresses ) );
		return $recipients_str;
	}

	function printPage( $query ) {
		$out = $this->getOutput();
		$request = $this->getRequest();

		$hide_label = wfMessage( 'hide' )->text();
		$show_label = wfMessage( 'show' )->text();
		$javascript_text =<<<END
	<script type="text/javascript">
function toggleRecipientsList(element_id, label_element) {
	element = document.getElementById(element_id);
	if (element.style.display == "none") {
		element.style.display = "block";
		label_element.innerHTML = "$hide_label";
	} else {
		element.style.display = "none";
		label_element.innerHTML = "$show_label";
	}
}
	</script>

END;
		$out->addScript( $javascript_text );

		if ( $request->getCheck( 'send' ) ) {
			$subject = $request->getVal( 'subject' );
			$body = $request->getVal( 'body' );
			$from = $this->fromString();
			$recip_num = 0;
			do {
				$recipients_str = self::recipientsString( $recip_num, 200 );
				if ( is_null ($recipients_str ) ) { break; }
				$headers = "From: $from\r\n";
				$headers .= "Bcc: $recipients_str\r\n";
				$to = self::toString();
				mail( $to, $subject, $body, $headers );
				$recip_num += 200;
			} while ( !is_null( $recipients_str ) );
			$text = wfMessage('emailsenttext')->text();
		} else {
			$recipients_str = self::recipientsString( 0, 1000 );
			$from_label = wfMessage( 'emailfrom' )->text();
			$from = htmlentities( $this->fromString() );
			$to_label = wfMessage( 'emailto' )->text();
			$to = htmlentities( self::toString() );
			$show_label = wfMessage( 'show' )->text();
			$subject_label = wfMessage( 'emailsubject' )->text();
			$message_label = wfMessage( 'emailmessage' )->text();
			$send_label = wfMessage( 'emailsend' )->text();
			$text =<<<END
	<form method="post">
	<p><strong>$from_label</strong> $from</p>
	<p><strong>$to_label</strong> $to</p>
	<p><strong>Bcc:</strong> (<a onclick="toggleRecipientsList('recipients_list', this)" style="cursor: pointer;">$show_label</a>)</p>
	<div id="recipients_list" style="font-size: xx-small; display: none;">$recipients_str</div>
	<p><strong>$subject_label</strong>
	<input type="text" size="60" name="subject" /></p>
	<p><strong>$message_label</strong></p>
	<p><textarea style="width: auto" rows="10" cols="100" name="body"></textarea></p>
	<p><input type="submit" name="send" value="$send_label" /></p>
	</form>

END;
		}
		$out->addHTML( $text );
	}
}
