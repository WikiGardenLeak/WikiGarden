<?php
/**
 * Lists the wikis the user owns - this page should only be viewable on
 * a main site.
 *
 * @author Yaron Koren
 */

class WGUserSites extends WGMainSiteSpecialPage {

	function __construct() {
		parent::__construct( 'UserSites' );
	}

	function printPage( $query ) {
		global $wgWikiGardenSubdomain;

		$user = $this->getUser();
		$skin = $this->getSkin();
		$out = $this->getOutput();

		// User must be logged in.
		if ( $user->isAnon() ) {
			$out->setPageTitle( wfMessage( 'watchnologin' )->text() );
			$specialTitle = SpecialPage::getTitleFor( 'UserSites' );
			$login_link = $skin->makeKnownLinkObj( SpecialPage::getTitleFor( 'Userlogin' ), wfMsgHtml( 'loginreqlink' ), 'returnto=' . $specialTitle->getPrefixedUrl() );
			$out->addHTML( wfMsgWikiHtml( 'watchlistanontext', $login_link ) );
			return;
		}

		// User must have their email authenticated.
		if ( ! $user->getEmailAuthenticationTimestamp() ) {
			global $wgSitename;
			$out->setPageTitle( wfMessage( 'wg_emailauthrequired' )->text() );
			$out->addHTML( Html::element( 'p', null, wfMessage( 'wg_emailauthrequireddesc', $wgSitename )->text() ) );
			return;
		 }

		$user_sites = WGSite::getAllOwnedByUser( $wgWikiGardenSubdomain, $user->getId() );
		if ( count( $user_sites ) == 0 ) {
			$text = "<p>" . wfMessage( 'wg_usersites_nosites' )->text() . "</p>\n";
		} else {
			$text = Html::element( 'p', null, wfMessage('wg_usersites_docu')->text() ) . "\n";
			$text .= "<ul>\n";
			foreach ( $user_sites as $site ) {
				$link_text = '<a href="' . $site->getURL() . '">' . $site->name . "</a>";
				if ( $site->delete_this ) {
					$link_text = "<em>$link_text</em> - this site is set to be deleted";
				}
				$text .= "<li>$link_text</li>\n";
			}
			$text .= "</ul>\n";
		}
		$cs = SpecialPageFactory::getPage( 'CreateSite' );
		$create_site_link = $skin->link( $cs->getTitle(), $cs->getDescription() );
		$text .= Html::rawElement( 'p', array( 'style' => 'font-weight: bold' ), $create_site_link ) . "\n";
		$out->addHTML( $text );
	}
}
