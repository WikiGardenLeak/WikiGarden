<?php
/**
 * Special page that displays editing statistics for the overall "garden",
 * by both day and month.
 *
 * @author Yaron Koren
 */

class WGEditStats extends WGSuperAdminSpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct( 'EditStats' );
	}

	static function getWidthConversionNum( $edits_array, $total_width ) {
		sort( $edits_array );
		$median_val = $edits_array[(int)(count( $edits_array ) * .97)];
		return ( $median_val / ( $total_width * .75 ) );
	}

	static function printColorBar( $width, $max_width, $color ) {
		if ( $width > $max_width ) {
			$num_pixels = $max_width;
			$extension = <<<END
				<div style="background: white; height: 8px; width: 2px; float: left;"></div>
				<div style="background: $color; height: 8px; width: 2px; float: left;"></div>
				<div style="background: white; height: 8px; width: 2px; float: left;"></div>
				<div style="background: $color; height: 8px; width: 2px; float: left;"></div>

END;
		} else {
			$num_pixels = $width;
			$extension = "";
		}
		$text =<<<END

				<div style="background: $color; height: 8px; width: {$num_pixels}px; float: left;"></div>
				$extension

END;
		return $text;
	}

	function printPage( $query ) {
		global $wgOut;
		global $wgWikiGardenDayEditsWidth, $wgWikiGardenMonthEditsWidth;

		// initialize array
		$edits_per_day = array();
		$color_per_day = array();
		$notable_sites_per_day = array();
		$edits_per_month = array();
		$first_day = strtotime('2007-05-11 1:00AM');
		$today = time();
		$day_of_week = 4;
		for ($cur_day = $first_day; $cur_day <= $today; $cur_day += 86400) {
			$cur_day_str = date('Y-m-d', $cur_day);
			$edits_per_day[$cur_day_str] = 0;
			$color_per_day[$cur_day_str] = ($day_of_week == 5 || $day_of_week == 6) ? "lightgreen" : "green";
			$day_of_week = ($day_of_week + 1) % 7;
		}

		$sites = WGSite::getAll();
		$dbr =& wfGetDB( DB_MASTER );
		$query = "SELECT DATE(rev_timestamp), count(*) FROM revision WHERE rev_minor_edit = 0 GROUP BY DATE(rev_timestamp)";
		$query2 = "SELECT DATE_FORMAT(rev_timestamp, '%Y-%m'), count(*) FROM revision WHERE rev_minor_edit = 0 GROUP BY DATE_FORMAT(rev_timestamp, '%Y-%m')";
		foreach ( $sites as $i => $site ) {
if ( $i < 200 ) continue;
			$dbr->selectDB( $site->db_name );
			$result = $dbr->query( $query );
			while ($row = $dbr->fetchRow( $result ) ) {
				$date = $row[0];
				$num_edits = $row[1];
				if ( $num_edits > 100 ) {
					if ( ! array_key_exists( $date, $notable_sites_per_day ) ) {
						$notable_sites_per_day[$date] = '';
					}
					$notable_sites_per_day[$date] .= "{$site->url} ($num_edits) ";
				}
				if ( array_key_exists( $date, $edits_per_day ) ) {
					$edits_per_day[$date] += $num_edits;
				}
			}
/*
			$result2 = $dbr->query( $query2 );
			while ($row = $dbr->fetchRow( $result2 ) ) {
				$month = $row[0];
				$num_edits = $row[1];
				if ( array_key_exists( $month, $edits_per_month ) ) {
					$edits_per_month[$month] += $num_edits;
				} else {
					$edits_per_month[$month] = $num_edits;
				}
			}
*/
		}

		$days_width_conversion_num = self::getWidthConversionNum( $edits_per_day, $wgWikiGardenDayEditsWidth );
		$months_width_conversion_num = self::getWidthConversionNum( $edits_per_month, $wgWikiGardenMonthEditsWidth );
		krsort( $edits_per_day );
		$most_edits = max( $edits_per_day );
		krsort( $edits_per_month );

		$date_header = wfMessage( 'listfiles_date' )->text();
		$num_edits_header = wfMessage( 'wg_editstats_numedits' )->text();
		$graph_header = wfMessage( 'wg_editstats_graph' )->text();
		$text =<<<END
<table class="wikitable">
	<thead>
		<tr>
			<th>$date_header</th>
			<th>$num_edits_header</th>
			<th>$graph_header</th>
			<th>Notable sites</th>
		</tr>
	</thead>
	<tbody>

END;

$dateNum = 0;
		foreach ( $edits_per_day as $date => $num_edits ) {
if ( $dateNum++ > 20 ) break;
			$color = $color_per_day[$date];
			$width = $num_edits / $days_width_conversion_num;
			$color_bar = self::printColorBar( $width, $wgWikiGardenDayEditsWidth, $color );
			if (array_key_exists( $date, $notable_sites_per_day ) ) {
				$notable_sites = $notable_sites_per_day[$date];
			} else {
				$notable_sites = "";
			}
			$text .=<<<END
		<tr>
			<td>$date</td>
			<td>$num_edits</td>
			<td>$color_bar</td>
			<td>$notable_sites</td>
		</tr>

END;
		}

		$month_header = wfMessage( 'wg_editstats_month' )->text();
		$text .=<<<END
	</tbody>
</table>

<table class="wikitable">
	<thead>
		<tr>
			<th>$month_header</th>
			<th>$num_edits_header</th>
			<th>$graph_header</th>
		</tr>
	</thead>
	<tbody>

END;
		foreach ($edits_per_month as $month => $num_edits) {
			$num_pixels = min( (int)( $num_edits / $months_width_conversion_num ), $wgWikiGardenMonthEditsWidth );
			$width = $num_edits / $months_width_conversion_num;
			$color = 'red';
			$color_bar = self::printColorBar( $width, $wgWikiGardenMonthEditsWidth, $color );
			$text .=<<<END
		<tr>
			<td>$month</td>
			<td>$num_edits</td>
			<td>$color_bar</td>
		</tr>

END;
		}
		$text .=<<<END
	</tbody>
</table>

END;
		$wgOut->addHTML( $text );
	}

}
