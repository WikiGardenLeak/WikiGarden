<?php
/**
 *
 * @author Yaron Koren
 */

class WGRobots extends SpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct( 'Robots' );
	}

	function execute( $query ) {
		global $wgOut;
		$wgOut->disable();
		print wfMsg( 'robots.txt' );
	}
}
