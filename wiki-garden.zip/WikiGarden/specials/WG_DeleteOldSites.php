<?php
/**
 *
 * @author Yaron Koren
 */

class WGDeleteOldSites extends WGSuperAdminSpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct('DeleteOldSites');
	}

	static function getSitesForDates( $start_date, $end_date ) {
		global $wgUser, $wgWikiGardenMainDB;

		$skin = $wgUser->getSkin();

		$all_sites = WGSite::getAll();
		$sites = array();
		$dbr = wfGetDB( DB_MASTER );
		$sql = "SELECT UNIX_TIMESTAMP(max(rc_timestamp)) FROM recentchanges";
		foreach ( $all_sites as $site ) {
			$dbr->selectDB( $site->db_name );
			$result = $dbr->query( $sql );
			$row = $dbr->fetchRow( $result );
			$site->last_updated = $row[0];
			if ($row[0] != '') {
				$site->last_updated_str = date('n/j/y', $row[0] - 18000);
			} else {
				$site->last_updated_str = "N/A";
			}

			$dbr->selectDB( $wgWikiGardenMainDB );
			$owner_name = $site->getOwner()->getName();
			$owner_title = Title::makeTitle( NS_USER, $owner_name );
			$site->owner_link = $skin->link( $owner_title, $owner_title->getText() );
			if ($site->last_updated == '') {
				if (($site->created_at > $start_date) && ($site->created_at < $end_date)) {
					$sites[] = $site;
				}
			} else {
				if (($site->last_updated > $start_date) && ($site->last_updated < $end_date)) {
					$sites[] = $site;
				}
			}
		}
		return $sites;
	}

	function makeDateString($updated_str, $created_at) {
		$created_str = date('n/j/y', $created_at);
		if ( $updated_str == 'N/A' ) {
			return "created $created_str";
		} else {
			return "last updated $updated_str";
		}
	}

	function emailAdmin( $email_address, $sites ) {
		global $wgSitename, $wgUser;

		$body =<<<END
Hello,


END;
		if ( count( $sites ) == 1 ) {
			$site = $sites[0];
			$subject = "[$wgSitename] Your wiki is set to be deleted";
			$site_url = $site[0];
			$site_name = $site[1];
			$last_updated = $site[2];
			$created_at = $site[3];
			$site_settings_page = SpecialPageFactory::getPage('SiteSettings');
			$site_settings_url = $site_settings_page->getTitle()->getLocalURL();
			$date_str = self::makeDateString($last_updated, $created_at);
			$body .=<<<END
A site you created on $wgSitename, $site_name, at $site_url, has not been updated in over six months (it was $date_str). This site is now set to be deleted, due to inactivity. However, you can easily save this site if you want, by logging in to the site, going to the following page:

$site_url$site_settings_url

going to the "Deletion" tab, and clicking on the "Undo deletion request" button. If you do so, the site will remain indefinitely. Otherwise, it will be deleted in around two weeks.

END;
		} else {
			$subject = "[$wgSitename] Some of your wikis are set to be deleted";
			$body .=<<<END
Several of the sites you have created on $wgSitename have not been updated in over six months:


END;
			foreach ( $sites as $site ) {
				$date_str = self::makeDateString( $site[2], $site[3] );
				$body .= "- {$site[1]}, at {$site[0]} ($date_str)\n";
			}
			$body .=<<<END

These sites are now set to be deleted, due to inactivity. If you want to prevent their deletion, just log in to any of the sites you want to save, go to the page "Special:SiteSettings" on that site, go to the "Deletion" tab, and click on the "Undo deletion request" button. If you do so, the site will remain indefinitely; otherwise it will be deleted in around two weeks.

END;
		}
		$body .=<<<END

Feel free to email me with any questions.

Thank you,
{$wgUser->getName()}

END;
		$from = "{$wgUser->getName()} <{$wgUser->getEmail()}>";
		$headers = "From: $from\r\n";
		mail( $email_address, $subject, $body, $headers );
		// @TODO - create $toUser and $fromUser objects, so the
		// below call can work.
		//UserMailer::send( $toUser, $fromUser, $subject, $body );
	}

	function emailAllAdmins( $sites ) {
		$user_sites = array();
		foreach ( $sites as $site ) {
			if ( ! $site->delete_this ) continue;
			$email = $site->getOwner()->getEmail();
			if ( array_key_exists( $email, $user_sites ) ) {
				$user_sites[$email][] = array( $site->getURL(), $site->name, $site->last_updated_str, $site->created_at );
			} else {
				$user_sites[$email] = array( array( $site->getURL(), $site->name, $site->last_updated_str, $site->created_at ) );
			}
		}
		foreach ( $user_sites as $user => $site_rows ) {
			self::emailAdmin( $user, $site_rows );
		}
		return array_keys( $user_sites );
	}

	function printPage( $query ) {
		global $wgOut, $wgRequest;

		$find_sites = $wgRequest->getCheck( 'find_sites' );
		$toggle_deletions = $wgRequest->getCheck( 'delete_undelete' );
		$email_admins = $wgRequest->getCheck( 'email_admins' );

		if ( $find_sites || $toggle_deletions || $email_admins ) {
			$start_date_str = $wgRequest->getVal( 'start_date' );
			$end_date_str = $wgRequest->getVal( 'end_date' );
			$start_date = strtotime( $start_date_str );
			$end_date = strtotime( $end_date_str );
			$new_start_date_str = date( 'n/j/Y', $start_date );
			$new_end_date_str = date( 'n/j/Y', $end_date );
			$sites = self::getSitesForDates( $start_date, $end_date );
		} else {
			$start_date = $end_date = null;
			$new_start_date_str = $new_end_date_str = null;
		}

		if ( $email_admins ) {
			$email_addresses = self::emailAllAdmins( $sites );
			$text = "<p>Email will be sent to the following administrators:</p>\n";
			$text .= "<p>" . implode( ', ', $email_addresses ) . "</p>\n";
			$wgOut->addHTML( $text );
			return;
		}

		$text =<<<END
	<p>Get sites last edited (or, if they were never edited, created) between the following two dates (non-inclusive):</p>
	<form action="" method="post">
	<input type="text" width=10 name="start_date" value="$new_start_date_str" /> to
	<input type="text" width=10 name="end_date" value="$new_end_date_str" />
	<p>(Use format mm/dd/yyyy)</p>
	<p>
	<input type="submit" name="find_sites" value="Find sites" />
	</p>

END;
		if (! $find_sites && ! $toggle_deletions && ! $email_admins) {
			$text .=<<<END
	</form>

END;
			$wgOut->addHTML($text);
			return;
		}

		if (count($sites) == 0) {
			$text .= "<p>No sites match these criteria.</p>\n";
			$wgOut->addHTML($text);
			return;
		}

		// handle deletions/undeletions
		if ($toggle_deletions) {
			foreach ($sites as $site) {
				if ($wgRequest->getCheck('delete_' . $site->id)) {
					$site->setDeletion(true);
				} elseif ($wgRequest->getCheck('undelete_' . $site->id)) {
					$site->setDeletion(false);
				}
			}
		}

		usort($sites, array("WGSiteList", 'last_updated_cmp'));
		$num_sites = count($sites);
		$site_name_label = wfMessage('wg_sitelist_sitename')->text();
		$owner_label = wfMessage('wg_sitelist_owner')->text();
		$date_created_label = wfMessage('wg_sitelist_datecreated')->text();
		$last_updated_label = wfMessage('wg_sitelist_lastupdated')->text();
		$service_level_label = wfMessage('servicelevel')->text();

		$text .=<<<END
<hr />
<p>There are a total of $num_sites wikis matching these criteria:</p>
<form action="" method="post">
<table class="wikitable site-list">
<thead>
<tr>
<th style="color: red">&#x2717;</th>
<th style="color: green">&#x2713;</th>
<th>$site_name_label</th>
<th>$owner_label</th>
<th>$date_created_label</th>
<th>$last_updated_label</th>
<th>$service_level_label</th>
</tr>
</thead>
<tbody>

END;
		foreach ($sites as $site) {
			$row_class = ($site->delete_this) ? "delete-this" : "";
			$site_url = $site->getURL();
			$created_at_str = date('n/j/y', $site->created_at);
			$text .=<<<END
<tr class="$row_class">

END;
			if ($site->delete_this) {
				$text .=<<<END
<td />
<td><input type="checkbox" name="undelete_{$site->id}" /></td>

END;
			} else {
				$text .=<<<END
<td><input type="checkbox" name="delete_{$site->id}" checked="checked" /></td>
<td />

END;
			}
			$text .=<<<END
<td><a href="{$site_url}">{$site->name}</a></td>
<td>$site->owner_link, {$site->getOwner()->getEmail()}</td>
<td>{$created_at_str}</td>
<td>{$site->last_updated_str}</td>
<td>{$site->getServiceLevelShortName()}</td>
</tr>

END;
		}
		$text .=<<<END
</tbody>
</table>
<input type="submit" name="delete_undelete" value="Set sites for deletion/undeletion" />
<hr />
<p>Press the button below to notify administrators of sites that have been set for deletion, by email:</p>
<p>
<input type="submit" name="email_admins" value="Email administrators" />
</p>
</form>

END;

		$wgOut->addHTML($text);
	}

}
