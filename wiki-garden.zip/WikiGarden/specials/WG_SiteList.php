<?php
/**
 * Lists all the sites/wikis, with relevant information about each one.
 *
 * @author Yaron Koren
 */

class WGSiteList extends WGSuperAdminSpecialPage {

	/**
	 * Constructor
	 */
	function __construct() {
		parent::__construct('SiteList');
	}

	static function cmpForColumn( $a, $b ) {
		global $wgWikiGardenComparisonField;
		$field = $wgWikiGardenComparisonField;
		if ( $a->$field == $b->$field ) {
			return self::created_at_cmp( $a, $b );
		}
		return ( $a->$field < $b->$field ) ? 1 : -1;
	}

	static function last_updated_cmp( $a, $b ) {
		if ( $a->last_updated == $b->last_updated ) {
			return self::created_at_cmp( $a, $b );
		}
		return ( $a->last_updated < $b->last_updated ) ? 1 : -1;
	}

	static function created_at_cmp($a, $b) {
		if ( $a->created_at == $b->created_at ) {
			return 0;
		}
		return ( $a->created_at < $b->created_at ) ? 1 : -1;
	}

	function printPage( $query ) {
		global $wgUser, $wgOut, $wgRequest, $wgDBname, $wgWikiGardenMainDB;
		global $wgSitename;

		$columnHeaders = array(
			'name' => array( wfMessage( 'listfiles_name' )->text(), 'linked_name', 'name' ),
			'owner' => array( wfMessage( 'wg_sitelist_owner' )->text(), 'owner_link', 'owner_name' ),
			'created_at' => array( wfMessage( 'wg_sitelist_datecreated' )->text(), 'created_at_str', 'created_at' ),
			'last_updated' => array( wfMessage( 'wg_sitelist_lastupdated' )->text(), 'last_updated_str', 'last_updated' ),
			'service_level' => array( wfMessage( 'servicelevel' )->text(), 'service_level' ),
			'views' => array( wfMessage( 'wg_sitelist_numviews' )->text(), 'total_views' ),
			'edits' => array( '# edits', 'edits_str' ),
			'users' => array( '# users', 'num_users' ),
			'jobs' => array( '# jobs', 'jobs_str' ),
			'mb_used' => array( 'MB used', 'mb_used' ),
		);

		$skin = $wgUser->getSkin();
		$sites = WGSite::getAll();
		$dbr = wfGetDB( DB_SLAVE );
		foreach ( $sites as $i => $site ) {
			$wgDBname = $site->db_name;
			$db_selected = $dbr->selectDB( $site->db_name );
			$site->db_missing = !$db_selected;
			if ( $db_selected ) {
				$site->setLastUpdatedDate();
				$site->setSiteStatistics();
				$row = $dbr->selectRow( 'job', 'COUNT(*) AS num_jobs', array() );
				$site->num_jobs = $row->num_jobs;
			} else {
				// Something is wrong - set all these values
				// to blank, to avoid error messages.
				$site->total_edits = "";
				$site->num_jobs = "";
				$site->last_updated = "";
				$site->last_updated_str = "";
				$site->total_views = "";
				$site->total_pages = "";
				$site->num_users = "";
			}

			$dbr->selectDB( $wgWikiGardenMainDB );
			$site->owner_name = $site->getOwner()->getName();
			$owner_title = Title::makeTitle( NS_USER, $site->owner_name );
			$site->owner_link = $skin->link( $owner_title, $owner_title->getText() );
		}

		$sortField = 'created_at';

		// Is there a less-hacky way of setting the field to be used
		// for comparison than a global variable?
		global $wgWikiGardenComparisonField;
		$wgWikiGardenComparisonField = $sortField;
		usort( $sites, array( "WGSiteList", 'cmpForColumn' ) );

		$num_sites = count( $sites );

		$site_list_page = Title::makeTitleSafe( NS_SPECIAL, 'SiteList' );

		// Get the local/relative URL for a few special pages, on
		// the assumption that it will be the same in each of the
		// wikis being listed.
		$manage_site_page = Title::makeTitleSafe( NS_SPECIAL, 'ManageSite' );
		$manage_site_url_part = $manage_site_page->getLocalURL();
		$recent_changes_page = Title::makeTitleSafe( NS_SPECIAL, 'RecentChanges' );
		$recent_changes_url_part = $recent_changes_page->getLocalURL();

		$text = Html::element( 'p', null, wfMessage( 'wg-sitelist-numsites', $num_sites, $wgSitename ) ) . "\n";
		$text .=<<<END
<table class="wikitable sortable site-list">
<thead>
<tr>
<th><img src="http://upload.wikimedia.org/wikipedia/commons/e/ea/Pencil.png" /></th>

END;
		foreach ( $columnHeaders as $columnField => $columnHeaderArray ) {
			$text .= Html::element( 'th', null, $columnHeaderArray[0] ) . "\n";
		}
		$text .=<<<END
</tr>
</thead>
<tbody>

END;
		foreach ( $sites as $i => $site ) {
			$row_class = ( $site->delete_this ) ? "delete-this" : "";
			if ( $site->db_missing ) {
				$row_class .= " db-missing";
			}
			$site_url = $site->getURL();
			$site->linked_name = "<a href=\"$site_url\">{$site->name}</a>";
			if ( $site->total_edits > 0 ) {
				$recent_changes_url = $site_url . $recent_changes_url_part;
				$site->edits_str = "<a href=\"{$recent_changes_url}\">{$site->total_edits}</a>";
			} else {
				$site->edits_str = "-";
			}
			$site->jobs_str = $site->num_jobs;
			$site->created_at_str = date( 'Y-n-j', $site->created_at );
			// We call $site->url here, not $site_url, because
			// we only want the subdomain. The naming should
			// probably be better somewhere.
			$site->mb_used = number_format( $site->getMegabytesUsed(), 1 );

			$text .=<<<END
<tr class="$row_class">
<td><a href="{$manage_site_url_part}/{$site->url}"><img src="http://upload.wikimedia.org/wikipedia/commons/e/ea/Pencil.png" /></a></td>

END;
			foreach ( $columnHeaders as $columnField => $columnHeaderArray ) {
				$displayField = $columnHeaderArray[1];
				if ( $displayField != '' ) {
					$displayText = $site->$displayField;
				} else {
					$displayText = '';
				}
				$text .= "<td>$displayText</td>\n";
			}
/*
<td><a href="{$site_url}">{$site->name}</a></td>
<td>$site->owner_link, {$site->getOwner()->getEmail()}</td>
<td>{$created_at_str}</td>
<td>{$site->last_updated_str}</td>
<td>{$site->getServiceLevelShortName()}</td>
<td>{$site->total_views}</td>
<td>$edits_str</td>
<td>{$site->total_pages}</td>
<td>{$site->num_users}</td>
<td>$mb_used</td>
*/
			$text .=<<<END
</tr>

END;
		}
		$text .=<<<END
</tbody>
</table>

END;

		$wgOut->addHTML($text);
	}

}
