<?php

if ( !defined( 'MEDIAWIKI' ) ) die();

###
# This is the path to your installation of WikiGarden as
# seen from the web. Change it if required ($wgScriptPath is the
# path to the base directory of your wiki). No final slash.
##
$wgWikiGardenScriptPath = $wgScriptPath . '/extensions/WikiGarden';
##

###
# This is the path to your installation of Wiki Garden as
# seen on your local filesystem.
##
$wgWikiGardenIP = $IP . '/extensions/WikiGarden';
##

###
# Other global variables
##
$wgWikiGardenDomain = "";
$wgWikiGardenDBNamePrefix = "";
$wgWikiGardenMainDB = $wgDBname;
$wgWikiGardenMainSubdomains = array( 'www' );
$wgWikiGardenAdminDefaultGroups = array( 'sysop', 'bureaucrat' );
$wgWikiGardenDayEditsWidth = 400;
$wgWikiGardenMonthEditsWidth = 600;
$wgWikiGardenPayPalIPNURL = null;
$wgWikiGardenServiceLevelsURL = null;
$wgWikiGardenSupportEmail = null;
$wgWikiGardenAnnouncementsEmail = null;

define( 'WIKI_GARDEN_VERSION', '1.0' );

/**********************************************/
/***** credits (see "Special:Version")    *****/
/**********************************************/
$wgExtensionCredits['other'][]= array(
	'path' => __FILE__,
	'name' => 'Wiki Garden',
	'version' => WIKI_GARDEN_VERSION,
	'author' => 'Yaron Koren',
	'url' => 'https://www.mediawiki.org/wiki/Extension:Wiki_Garden',
	'descriptionmsg' => 'wikigarden-desc',
);

$wgExtensionMessagesFiles['WikiGarden'] = $wgWikiGardenIP . '/WikiGarden.i18n.php';

$wgExtensionFunctions[] = 'WGUtils::initializeSite';

$wgHooks['UserLoadFromDatabase'][] = 'WGUtils::setUser';
//$wgHooks['UploadForm:BeforeProcessing'][] = 'WGUtils::checkUploadQuota';
$wgHooks['UploadVerification'][] = 'WGUtils::checkUploadQuota';
$wgHooks['PersonalUrls'][] = 'WGUtils::addPersonalURLs';
$wgHooks['UserGetRights'][] = 'WGUtils::blockFromReading';
$wgHooks['AdminLinks'][] = 'WGUtils::addToAdminLinks';
$wgHooks['ImageOpenShowImageInlineBefore'][] = 'WGUtils::handleURLAliasImages';
$wgHooks['ImageBeforeProduceHTML'][] = 'WGUtils::handleURLAliasImages2';
$wgHooks['ThumbBeforeProduceHTML'][] = 'WGUtils::handleURLAliasThumbs';
$wgHooks['GetThumbURL'][] = 'WGUtils::handleURLAliasThumbs2';

//$wgHooks['SiteSettingsConstructSite'][] = 'WGUtils::constructSite';
$wgHooks['SiteSettingsCreateTableBefore'][] = 'WGSiteSettings::turnOffSSDBCreation';
$wgHooks['SiteSettingsCreateTableAfter'][] = 'WGSiteSettings::describeDBSchema';
$wgHooks['SiteSettingsCreateStartingValues'][] = 'WGSiteSettings::createImagesDirectory';
$wgHooks['SiteSettingsGetFields'][] = 'WGSiteSettings::addSiteSettingsFields';
$wgHooks['SiteSettingsLoadSettingsStart'][] = 'WGSiteSettings::setupBeforeLoadSettings';
$wgHooks['SiteSettingsLoadSettingsEnd'][] = 'WGSiteSettings::loadSettings';
//$wgHooks['SiteSettingsGetDB'][] = 'WGUtils::selectMainDB';
$wgHooks['SiteSettingsNewFromDBBegin'][] = 'WGSiteSettings::addURLCondition';
$wgHooks['SiteSettingsDBConditions'][] = 'WGSiteSettings::addIDCondition';
$wgHooks['SiteSettingsMainTab'][] = 'WGSiteSettings::printSubdomainAliasInput';
$wgHooks['SiteSettingsTabs'][] = 'WGSiteSettings::printServiceLevelTab';
$wgHooks['SiteSettingsTabs'][] = 'WGSiteSettings::printDeletionTab';
$wgHooks['SiteSettingsSaveTabSettings'][] = 'WGSiteSettings::checkTabSettingsBeforeSaving';
$wgHooks['SiteSettingsUpdate'][] = 'WGSiteSettings::updateDeletionState';
$wgHooks['SiteSettingsPrivacyOptionDisplay'][] = 'WGSiteSettings::possiblyDisallowPrivacyOption';
$wgHooks['SiteSettingsPrivacyOptionsDisplay'][] = 'WGSiteSettings::possiblyDisplayPrivacyOptionsFooter';
$wgHooks['SiteSettingsFaviconInput'][] = 'WGSiteSettings::possiblyDisableFaviconInput';
$wgHooks['SiteSettingsGetPrivacyLevel'][] = 'WGSiteSettings::possiblyDisallowPrivateSite';
$wgHooks['SiteSettingsGetImagesSubdirectoryName'][] = 'WGSiteSettings::setImagesSubdirectoryName';
$wgHooks['SiteSettingsStoreLoadValue'][] = 'WGSite::loadSiteData';

// register all special pages and other classes
$wgSpecialPages['UserSites'] = 'WGUserSites';
$wgAutoloadClasses['WGUserSites'] = $wgWikiGardenIP . '/specials/WG_UserSites.php';
$wgSpecialPages['CreateSite'] = 'WGCreateSite';
$wgAutoloadClasses['WGCreateSite'] = $wgWikiGardenIP . '/specials/WG_CreateSite.php';
$wgSpecialPages['ServiceLevel'] = 'WGServiceLevel';
$wgAutoloadClasses['WGServiceLevel'] = $wgWikiGardenIP . '/specials/WG_ServiceLevel.php';
$wgAutoloadClasses['WGSiteSettings'] = $wgWikiGardenIP . '/includes/WG_SiteSettings.php';
$wgSpecialPages['ManageSite'] = 'WGManageSite';
$wgAutoloadClasses['WGManageSite'] = $wgWikiGardenIP . '/specials/WG_ManageSite.php';
$wgSpecialPages['SiteList'] = 'WGSiteList';
$wgAutoloadClasses['WGSiteList'] = $wgWikiGardenIP . '/specials/WG_SiteList.php';
//$wgSpecialPages['RenderTest'] = 'WGRenderTest';
//$wgAutoloadClasses['WGRenderTest'] = $wgWikiGardenIP . '/specials/WG_RenderTest.php';
$wgSpecialPages['DeleteOldSites'] = 'WGDeleteOldSites';
$wgAutoloadClasses['WGDeleteOldSites'] = $wgWikiGardenIP . '/specials/WG_DeleteOldSites.php';
$wgSpecialPages['EditStats'] = 'WGEditStats';
$wgAutoloadClasses['WGEditStats'] = $wgWikiGardenIP . '/specials/WG_EditStats.php';
$wgSpecialPages['EmailAdmins'] = 'WGEmailAdmins';
$wgAutoloadClasses['WGEmailAdmins'] = $wgWikiGardenIP . '/specials/WG_EmailAdmins.php';
$wgSpecialPages['Robots'] = 'WGRobots';
$wgAutoloadClasses['WGRobots'] = $wgWikiGardenIP . '/specials/WG_Robots.php';

$wgAutoloadClasses['WGUtils'] = $wgWikiGardenIP . '/includes/WG_Utils.php';
$wgAutoloadClasses['WGMainSiteSpecialPage'] = $wgWikiGardenIP . '/includes/WG_MainSiteSpecialPage.php';
$wgAutoloadClasses['WGSuperAdminSpecialPage'] = $wgWikiGardenIP . '/includes/WG_SuperAdminSpecialPage.php';
$wgAutoloadClasses['WGSite'] = $wgWikiGardenIP . '/includes/WG_Site.php';
//$wgAutoloadClasses['WGFieldLevel'] = $wgWikiGardenIP . '/includes/WG_FieldLevel.php';
//$wgAutoloadClasses['WGSiteSettings2'] = $wgWikiGardenIP . '/includes/WG_SiteSettings2.php';

$wgAvailableRights[] = 'createsite';
$wgGroupPermissions['*']['createsite'] = true;
$wgAvailableRights[] = 'administerwikis';
$wgGroupPermissions['sysop']['administerwikis'] = true;

$wgWikiGardenResourceTemplate = array(
	'localBasePath' => $wgWikiGardenIP,
	'remoteExtPath' => 'WikiGarden'
);
$wgResourceModules += array(
	'ext.wikigarden.main' => $wgWikiGardenResourceTemplate + array(
		'styles' => array(
			'WikiGarden.css',
		),
	),
);

/**********************************************/
/***** other global helpers               *****/
/**********************************************/

function wfWikiGardenConnectToDB() {
	global $wgDBserver, $wgDBuser, $wgDBpassword, $wgWikiGardenMainDB;

	$conn = mysql_connect( $wgDBserver, $wgDBuser, $wgDBpassword );
	if ( ! $conn ) {
		global $wgSitename;
		$text =<<<END
<h1>$wgSitename is experiencing temporary technical difficulties. Sorry for the
inconvenience.</h1>

END;
		die( $text );
	}
	return mysql_select_db( $wgWikiGardenMainDB, $conn );
}

function wfWikiGardenGetSiteData() {
	global $wgWikiGardenSubdomain;
	global $wgWikiGardenDomain, $wgWikiGardenIsURLAlias;

	wfWikiGardenConnectToDB();

	$selectClause = "SELECT url, default_skin, namespace, use_liquid_threads, use_wysiwyg_editor, disable_caching, questy_captcha_question, questy_captcha_answer";

	$wgWikiGardenIsURLAlias = false;
	$serverName = $_SERVER["SERVER_NAME"];
	$domain_name_size = strlen( $wgWikiGardenDomain );
	if ( substr( $serverName, 0 - $domain_name_size ) == $wgWikiGardenDomain ) {
		$subdomain = substr( $serverName, 0, -1 - $domain_name_size );
		if ( $subdomain == '' ) $subdomain = 'www';

		$sql = "$selectClause FROM site_settings WHERE url = '$subdomain' OR url_alias = '$subdomain'";
		$res = mysql_query($sql);
		if (mysql_num_rows($res)) {
			$row = mysql_fetch_object($res);
			if ($row->url !== $subdomain) {
				$wgWikiGardenIsURLAlias = true;
			}
			return $row;
		}
	}

	// See if this matches a virtual domain - 
	// remove subdomain, if any, from the domain name.
	if ( substr_count( $serverName, '.' ) > 1) {
		$domain_name = substr( strstr( $serverName, '.' ), 1);
	} else {
		$domain_name = $serverName;
	}
	$sql = "$selectClause FROM site_settings WHERE virtual_domain = '$domain_name'";
	$res = mysql_query( $sql );
	if ( mysql_num_rows( $res ) ) {
		$row = mysql_fetch_object( $res );
		return $row;
	}

	return null;
}
