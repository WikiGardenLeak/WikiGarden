<?php

class WGFieldLevel {

	var $id, $name, $description;

	static function create( $id, $name, $description ) {
		$fl = new WGFieldLevel();
		$fl->id = $id;
		$fl->name = $name;
		$fl->description = $description;
		return $fl;
	}
}
