<?php
/**
 * Defines a class, WGSuperAdminSpecialPage, that can only be accessed on
 * the "main" wiki in the wiki farm, and only by "super-admins" -
 * administrators of that wiki.
 *
 * @author Yaron Koren
 */

class WGSuperAdminSpecialPage extends WGMainSiteSpecialPage {

	/**
	 * Constructor
	 */
	function __construct( $page_name ) {
		parent::__construct( $page_name );
	}

	function execute( $query ) {
		# Permission check
		global $wgUser, $wgOut;
		if( !$wgUser->isAllowed( 'administerwikis' ) ) {
			$this->setHeaders();
			$wgOut->permissionRequired( 'administerwikis' );
			return;
		}

		parent::execute( $query );
	}
}
