<?php

class WGSite {

	// @TODO - these should not be here.
	public static $use_liquid_threads, $show_infobox,
		$hide_main_edit_tab, $rename_edit_tabs,
		$use_drilldown_tag_cloud, $tabs_for_categories;

	static function getFields() {
		global $wgRightsText, $wgRightsUrl, $wgDefaultSkin;
		global $wgWikiGardenServiceSettings;

		$starting_service_level = key( $wgWikiGardenServiceSettings );

		$allFields = array(
			'preset' => array(
				'id' => array( false, null ),
				'url' => array( false, null ),
				'owner_id' => array( false, null ),
				'db_name' => array( false, null ),
				'created_at' => array( false, null ),
			),
			'main' => array(
				'name' => array( false, null ),
				'url_alias' => array( false, null ),
				'namespace' => array( false, null ),
				'language_code' => array( false, null ),
				'hours_timezone_offset' => array( false, 0),
				'use_american_dates' => array( true, true ),
				'use_24_hour_time' => array( true, false ),
				'show_page_counters' => array( true, true ),
				'use_subpages' => array( true, false ),
				'allow_external_images' => array( true, false ),
				'allow_lowercase_page_names' => array( true, false ),
				'copyright_text' => array( false, $wgRightsText ),
				'copyright_url' => array( false, $wgRightsUrl ),
			),
			'skin' => array(
				'default_skin' => array( false, $wgDefaultSkin ),
				'background_color' => array( false, null ),
				'sidebar_color' => array( false, null ),
				'sidebar_border_color' => array( false, null ),
			),
			'logo' => array(
				'logo_file' => array( false, null ),
				'favicon_file' => array( false, null ),
			),
			'privacy' => array(
				'viewing_policy_id' => array( false, 1 ),
				'registration_policy_id' => array( false, 1 ),
				'editing_policy_id' => array( false, 2 ),
				'questy_captcha_question' => array( false, null ),
				'questy_captcha_answer' => array( false, null ),
			),
			'web services' => array(
				'google_analytics_id' => array( false, null ),
				'google_verification_id' => array( false, null ),
				'google_adsense_id' => array( false, null ),
				'google_ad_slot' => array( false, null ),
			),
			'service level' => array(
				'service_level' => array( false, $starting_service_level ),
			),
			'deletion' => array(
				'delete_this' => array( true, false ),
			),
			'admin-only' => array(
				'virtual_domain' => array( false, null ),
				'custom_skin' => array( false, null ),
				'disable_caching' => array( true, false ),
			)
		);
		wfRunHooks( 'WikiGardenGetFields', array( &$allFields ) );
		return $allFields;
	}

	static function selectClause() {
		$allFieldNames = array();
		foreach ( self::getFields() as $area => $fields ) {
			$allFieldNames = array_merge( $allFieldNames, array_keys( $fields ) );
		}
		$select_clause = implode( ', ', $allFieldNames );
		$select_clause = str_replace( 'created_at', 'UNIX_TIMESTAMP(created_at) AS created_at', $select_clause );
		return $select_clause;
	}

	static function createFromRow( $row ) {
		$s = new WGSite();
		foreach ( $row as $var => $val )
			$s->{$var} = $val;
		return $s;
	}

	function updateFromQuery( $query ) {
		foreach ( self::getFields() as $area => $fields ) {
			foreach ( $fields as $fieldName => $fieldVals ) {
				$isBoolean = $fieldVals[0];
				if ( $isBoolean) {
					$this->$fieldName = array_key_exists( $fieldName, $query ) ? 1 : 0;
				} else {
					if ( array_key_exists( $fieldName, $query ) ) {
						$this->$fieldName = $query[$fieldName];
					}
				}
			}
		}
	}

	function setLogo( $logo_name, $tmp_file_name ) {
		global $IP;

		if ( ! is_uploaded_file( $tmp_file_name ) ) {
			return "File failed to upload; unknown error.";
		}
		$logo_dir = $IP . "/skins/common/images/logos/" . $this->url;
		// if this directory doesn't already exist, create it
		if ( ! file_exists( $logo_dir ) )
			mkdir( $logo_dir );
		$new_file_name = $logo_dir . "/" . $logo_name;
		if ( ! move_uploaded_file( $tmp_file_name, $new_file_name ) ) {
			return "Unable to move temp file.";
		}

		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', array( 'logo_file' => $logo_name ),
			array( 'id' => $this->id ) );
	}

	function removeLogo() {
		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', array( 'logo_file' => '' ),
			array( 'id' => $this->id ) );
	}

	function setFavicon( $favicon_name, $tmp_file_name ) {
		global $IP;

		if ( ! is_uploaded_file( $tmp_file_name ) ) {
			return "File failed to upload; unknown error.";
		}
		$favicon_dir = $IP . "/skins/common/images/favicon/" . $this->url;
		// if this directory doesn't already exist, create it
		if ( ! file_exists( $favicon_dir ) )
			mkdir( $favicon_dir );
		$new_file_name = $favicon_dir . "/" . $favicon_name;
		if ( ! move_uploaded_file( $tmp_file_name, $new_file_name ) ) {
			return "Unable to move temp file.";
		}

		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', array( 'favicon_file' => $favicon_name ),
			array( 'id' => $this->id ) );
	}

	function removeFavicon() {
		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', array( 'favicon_file' => '' ),
			array( 'id' => $this->id ) );
	}

	static function create( $url, $site_name, $referring_site, $owner_id, $db_name ) {
		global $wgLanguageCode, $IP;

		if ( $referring_site == 'www' )
			$referring_site = '';
		$language_code = $wgLanguageCode;
		// TODO - make this automated
		if ( $referring_site == 'de' )
			$language_code = 'de';

		$fieldsAndStartingValues = array();
		foreach ( self::getFields() as $area => $fields ) {
			foreach ( $fields as $fieldName => $fieldVals ) {
				$defaultValue = $fieldVals[1];
				$fieldsAndStartingValues[$fieldName] = $defaultValue;
			}
		}
		unset( $fieldsAndStartingValues['id'] );
		$fieldsAndStartingValues['url'] = $url;
		$fieldsAndStartingValues['name'] = $site_name;
		$fieldsAndStartingValues['referring_site'] = $referring_site;
		$fieldsAndStartingValues['owner_id'] = $owner_id;
		$fieldsAndStartingValues['db_name'] = $db_name;
		$fieldsAndStartingValues['namespace'] = $site_name;
		$fieldsAndStartingValues['language_code'] = $language_code;

		$db = WGUtils::getMainDBForWriting();
		$db->insert( 'site_settings', $fieldsAndStartingValues );
		// get the ID, so we can save it into action_history
		$row = $db->selectRow( 'site_settings', 'id', array( 'url' => $url ) );
		$db->insert( 'action_history',
			array( 'site_id' => $row->id, 'site_url' => $url, 'action' => 'Created' )
		);

		// Create images directory.
		$images_dir = "$IP/images/$url";
		// Check if directory already exists, in case a wiki
		// at this URL existed and was then deleted.
		if ( ! file_exists( $images_dir ) ) {
			mkdir( $images_dir );
		}

	}

	static function find( $id ) {
		global $wgProfiling;

		$wgProfiling = false;
		$db = WGUtils::getMainDBForReading();
		$row = $db->selectRow( 'site_settings', WGSite::selectClause(),
			array( 'id' => $id ) );
		if ( empty( $row ) ) return null;
		return WGSite::createFromRow( $row );
	}

	static function findByURL( $url ) {
if ( in_array( $url, array ( 'ltfandom', 'northantscamra', 'ragnaroktrans', 'pokemon', 'sockbook', 'sesandbox', 'awa', 'ulm', 'socialecologicalsystems', 'cprtheory', 'lat', 'sozialform', 'pixelnations', 'fanstuff2archive', 'notizie', 'gladiator', 'doctorwho', 'retourverslefutur', 'letronedefer', 'touristtrophydeliledeman', 'indianajonesetladernierecroisade', 'lingvo', 'sumberhukum', 'wikimir', 'pixelwiki', /*'spongefan',*/ 'pokemonwiki2007', 'looneytunes', 'dono', 'challengertennis', 'ophicleide' ) ) ) {
        WGUtils::print404Error();
}
		global $wgProfiling, $wgDBname;

		$wgProfiling = false;
		$db = WGUtils::getMainDBForReading();
		$row = $db->selectRow( 'site_settings', WGSite::selectClause(),
			array( 'url' => $url ) );
		if ( !empty( $row ) ) {
			// back to real DB
			$db->selectDB( $wgDBname );
			return WGSite::createFromRow( $row );
		}
		// If we're still here, try looking up by URL alias as well.
		$row = $db->selectRow( 'site_settings', WGSite::selectClause(),
			array( 'url_alias' => $url ) );
		if ( !empty( $row ) ) {
			// back to real DB
			$db->selectDB( $wgDBname );
			return WGSite::createFromRow( $row );
		}

		// Found nothing!
		$db->selectDB( $wgDBname );
		return null;
	}

	function loadSettings() {
		global $wgSitename, $wgDBname, $wgLocalInterwiki, $wgMetaNamespace;
		global $wgContLanguageCode, $wgContLang, $wgLanguageCode, $wgLang;
		global $wgLocalTZoffset, $wgAmericanDates;
		global $wgDisableCounters, $wgAllowExternalImages, $wgCapitalLinks;
		global $wgRightsText, $wgRightsUrl;
		global $wgNamespacesWithSubpages;

		$i = 0;
		$wgSitename = $this->name;
		$wgLocalInterwiki = $wgSitename;
		$wgDBname = $this->db_name;
		$db = wfGetDB( DB_SLAVE );
		$db_selected = $db->selectDB( $wgDBname );
		if ( !$db_selected ) {
			die( "Error: database '$wgDBname' not found for this wiki." );
		}
		//$wgMetaNamespace = str_replace(' ', '_', $this->namespace);

		// These should always be the same, according to Setup.php.
		$wgLanguageCode = $wgContLanguageCode = $this->language_code;
		$wgContLang->setCode( $wgContLanguageCode );

		$wgLocalTZoffset = $this->hours_timezone_offset * 60;
		$wgAmericanDates = $this->use_american_dates;
		$wgDisableCounters = ! $this->show_page_counters;
		if ( $this->use_subpages ) {
			$wgNamespacesWithSubpages = array_fill( 0, 200, true );
		}
		$wgAllowExternalImages = $this->allow_external_images;
		$wgCapitalLinks = ! $this->allow_lowercase_page_names;
		// Handling of 'use_liquid_threads' should be done in
		// LocalSettings.php.
		$wgRightsText = $this->copyright_text;
		$wgRightsUrl = $this->copyright_url;
		$this->setServiceLevelSettings();
		$this->setAppearanceSettings();
		$this->setPermissions();

		wfRunHooks( 'WikiGardenLoadSettings', array( &$this ) );

/*
		if ($this->disable_caching) {
			$wgEnableParserCache = false;
			$wgCachePages = false;
		}
*/
		return true;
	}

	function setServiceLevelSettings() {
		SSStore::addValue( 'megabytesAllowed', $this->getMegabytesAllowed() );
		SSStore::addValue( 'canHaveVirtualDomain', $this->canHaveVirtualDomain() );
	}

	function setPermissions() {
		global $wgGroupPermissions;

		// 'skipcaptcha' is used for both editing and registration
		$wgGroupPermissions['*']['skipcaptcha'] = false;
		//$wgGroupPermissions['autoconfirmed']['skipcaptcha'] = false;
		if ( $this->editing_policy_id == 2 ) { // 'Open with CAPTCHA'
		} elseif ( $this->editing_policy_id == 3 ) { // Closed
			$wgGroupPermissions['*']['edit'] = false;
		} elseif ( $this->editing_policy_id == 4 ) { // Very closed
			$wgGroupPermissions['*']['edit'] = false;
			$wgGroupPermissions['user']['edit'] = false;
			$wgGroupPermissions['sysop']['edit'] = true;
			$wgGroupPermissions['bureaucrat']['edit'] = true;
		}

		// No need to handle 'Public' - that's the default.
		// We do need to handle cases where the service level
		// doesn't allow private wikis, though - that can happen
		// if a wiki goes to a higher level, is set to 'private',
		// then comes back.
		if ( ! $this->canBePrivate() ) {
			// do nothing
		} elseif ( $this->viewing_policy_id >= 2 ) { // Private
			$wgGroupPermissions['*']['read'] = false;
		}

		// No need to handle 'Open' - that's the default
		if ( $this->registration_policy_id == 3 ) { // OpenID-only
			global $wgOpenIDOnly;
			$wgOpenIDOnly = true;
		} elseif ( $this->registration_policy_id == 2 ) { // Closed
			$wgGroupPermissions['*']['createaccount'] = false;
		}
	}

	function setAppearanceSettings() {
		if ( $this->custom_skin != null ) {
			global $wgValidSkinNames;
			$wgValidSkinNames[strtolower( $this->custom_skin )] = $this->custom_skin;
		}
		$inline_css = '';
		if ( $this->background_color != '' ) {
			$inline_css .=<<<END
body {
	background: #{$this->background_color};
	background-color: #{$this->background_color};
}
#mw-page-base {
	background-color: #{$this->background_color};
	background-image: none;
}

END;
		}
		if ( $this->sidebar_color != '' ) {
			$inline_css .= ".pBody {background-color: #{$this->sidebar_color};} ";
		}
		if ( $this->sidebar_border_color != '' ) {
			$inline_css .= ".pBody {border-color: #{$this->sidebar_border_color};} ";
		}
		if ( $inline_css != '' ) {
			global $wgOut;
			$wgOut->addScript("<style type=\"text/css\">$inline_css</style>\n");
		}
		$logo_filename = str_replace( ' ', '%20', $this->logo_file ); // regular spaces aren't handled correctly by Firefox
		global $wgLogo, $wgScriptPath, $wgWikiGardenSubdomain;
		// This code appears to no longer be necessary.
		/*
		global $wgWikiGardenIsURLAlias;
		if ( $wgWikiGardenIsURLAlias ) {
			global $wgWikiGardenDomain;
			$domain = "http://{$this->url}." . $wgWikiGardenDomain;
			$wgScriptPath = $domain . $wgScriptPath;
		}
		*/
		if ( $logo_filename != null ) {
			$wgLogo = "$wgScriptPath/skins/common/images/logos/" . $logo_filename;
		} elseif ( ! WGUtils::currentSiteIsMainSite() ) {
			global $wgWikiGardenDefaultLogo;
			$wgLogo = $wgWikiGardenDefaultLogo;
		}
		$favicon_filename = str_replace( ' ', '%20', $this->favicon_file ); // regular spaces aren't handled correctly by Firefox
		global $wgFavicon;
		if ( $favicon_filename != null ) {
			$wgFavicon = "$wgScriptPath/skins/common/images/favicon/" . $favicon_filename;
		} elseif ( ! WGUtils::currentSiteIsMainSite() ) {
			$wgFavicon = "/favicon.ico";
		}
	}

	function getOwner() {
		return User::newFromId( $this->owner_id );
	}

	function getURL() {
		if ( $this->virtual_domain != '' ) {
			return "http://{$this->virtual_domain}";
		} elseif ( $this->url_alias != '' ) {
			global $wgWikiGardenDomain;
			return "http://{$this->url_alias}." . $wgWikiGardenDomain;
		} else {
			global $wgWikiGardenDomain;
			return "http://{$this->url}." . $wgWikiGardenDomain;
		}
	}

	function getMainAdmin() {
		$dbr = wfGetDB( DB_SLAVE );
		$dbr->selectDB( $this->db_name );
		$row = $dbr->selectRow( 'user', 'user_name', array( 'user_id = 1' ) );
		return $row->user_name;
	}

	function setLastUpdatedDate() {
		$dbr = wfGetDB( DB_SLAVE );
		$dbr->selectDB( $this->db_name );
		$row = $dbr->selectRow( 'recentchanges', 'UNIX_TIMESTAMP(max(rc_timestamp)) AS time', array() );
		if ( $row->time != '' ) {
			$this->last_updated = $row->time - 18000;
			$this->last_updated_str = date( 'Y-n-j', $this->last_updated );
		} else {
			$this->last_updated = '';
			$this->last_updated_str = "N/A";
		}
	}

	function setSiteStatistics() {
		$dbr = wfGetDB( DB_SLAVE );
		$row = SiteStats::doLoad( $dbr );
		if ( empty( $row ) ) {
			$this->total_views = 0;
			$this->total_edits = 0;
			$this->total_pages = 0;
			$this->num_users = 0;
		} else {
			$this->total_views = $row->ss_total_views;
			$this->total_edits = $row->ss_total_edits;
			$this->total_pages = $row->ss_total_pages;
			$this->num_users = $row->ss_users;
		}
	}

	public function getMegabytesUsed() {
		return WGSiteSettings::getMegabytesUsedForSite( $this->url );
	}

	public static function loadSiteData( $fieldName, &$value ) {
		if ( $fieldName == 'megabytesUsed' ) {
			$siteSubdomain = SSStore::getValue('url');
			$value = WGSiteSettings::getMegabytesUsedForSite( $siteSubdomain );
		}
		return true;
	}

	function getServiceLevelSetting( $key ) {
		global $wgWikiGardenServiceSettings;
		return $wgWikiGardenServiceSettings[$this->service_level][$key];
	}

	public function getMegabytesAllowed() {
		return $this->getServiceLevelSetting( 'disk megabytes' );
	}

	public function getServiceLevelName() {
		return $this->getServiceLevelSetting( 'name' );
	}

	public function getServiceLevelShortName() {
		return $this->getServiceLevelSetting( 'short name' );
	}

	public function requiresSubscription() {
		return ( $this->getServiceLevelSetting( 'monthly rate' ) > 0 );
	}

	public function canBePrivate() {
		return $this->getServiceLevelSetting( 'private allowed' );
	}

	public function canHaveAds() {
		return $this->getServiceLevelSetting( 'ads allowed' );
	}

	public function canHaveFavicon() {
		return $this->getServiceLevelSetting( 'favicon allowed' );
	}

	public function canHaveVirtualDomain() {
		return $this->getServiceLevelSetting( 'virtual domain allowed' );
	}

	static function getAll() {
		$db = WGUtils::getMainDBForReading();
		$rows = $db->select( 'site_settings', WGSite::selectClause(), array(),
			null, array( 'ORDER BY' => 'id' ) );
		$all = array();
		foreach ( $rows as $row ) {
			$all[] = WGSite::createFromRow( $row );
		}
		return $all;
	}

	static function getAllForDeletion() {
		$db = WGUtils::getMainDBForReading();
		$rows = $db->select( 'site_settings', WGSite::selectClause(),
			array( 'delete_this' => true ),
			null, array( 'ORDER BY' => 'id' ) );
		$all = array();
		foreach ( $rows as $row ) {
			$all[] = WGSite::createFromRow( $row );
		}
		return $all;
	}

	static function getAllOwnedByUser( $referring_site, $user_id ) {
		$all = array();
		if ( $referring_site == 'www' ) {
			$referring_site = '';
		}
		$db = WGUtils::getMainDBForReading();
		$rows = $db->select( 'site_settings', WGSite::selectClause(),
			array( 'referring_site' => $referring_site, 'owner_id' => $user_id ),
			null, array( 'ORDER BY' => 'name' )
		);
		foreach ( $rows as $row ) {
			$all[] = WGSite::createFromRow( $row );
		}
		return $all;
	}

	function saveMWSettings() {
		$db = WGUtils::getMainDBForWriting();
		if ( empty( $this->url_alias ) ) {
			$this->url_alias = null;
		} else {
			// Make sure this URL alias hasn't already been
			// taken by someone else.
			$row = $db->selectRow( 'site_settings', 'url',
				"id != {$this->id} AND (url = '{$this->url_alias}' OR url_alias = '{$this->url_alias}')"
			);
			if ( ! empty( $row ) ) {
				return "'{$this->url_alias}' cannot be used as a URL alias because it has already been taken.";
			}
		}
		$valuesToUpdate = array();
		$allFields = self::getFields();
		foreach ( $allFields['main'] as $fieldName => $fieldVals ) {
			$valuesToUpdate[$fieldName] = $this->$fieldName;
		}
		$db->update( 'site_settings', $valuesToUpdate,
			array( 'id' => $this->id )
		);
	}

	function saveSettingsForTab( $tabName ) {
		$valuesToUpdate = array();
		$allFields = self::getFields();
		foreach ( $allFields[$tabName] as $fieldName => $fieldVals ) {
			$valuesToUpdate[$fieldName] = $this->$fieldName;
		}

		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', $valuesToUpdate,
			array( 'id' => $this->id )
		);
	}

	/**
	 * Save site settings from the page Special:ManageSite, accessible
	 * only by "super-admins".
	 */
	function saveSuperAdminSettings() {
		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings',
			array(
				'service_level' => $this->service_level,
				'editing_policy_id' => $this->editing_policy_id,
				'registration_policy_id' => $this->registration_policy_id,
				'virtual_domain' => $this->virtual_domain,
				'custom_skin' => $this->custom_skin,
				'delete_this' => $this->delete_this,
			),
			array( 'id' => $this->id )
		);
	}

	function setDeletion( $delete ) {
		$this->delete_this = $delete;
		$db = WGUtils::getMainDBForWriting();
		$db->update( 'site_settings', array( 'delete_this' => $delete ),
			array( 'id' => $this->id ) );
		$action = $delete ? 'Deletion requested' : 'Deletion request undone';
		$query2 = "INSERT INTO action_history (site_id, site_url, action) VALUES ({$this->id}, '{$this->url}', '$action')";
		$db->query( $query2 );
	}

	// copied from http://nashruddin.com/Remove_Directories_Recursively_with_PHP
	static function rmdir_recursive( $dir ) {
		if ( ! file_exists( $dir ) ) return 0;

		$num_deleted_files = 0;
		$files = scandir( $dir );
		array_shift( $files ); // remove '.' from array
		array_shift( $files ); // remove '..' from array

		foreach ( $files as $file ) {
			$file = $dir . '/' . $file;
			if ( is_dir( $file ) ) {
				self::rmdir_recursive( $file );
			} else {
				unlink( $file );
				$num_deleted_files++;
			}
		}
		rmdir( $dir );
		return $num_deleted_files;
	}

	/**
	 * This one's no joke! Only call if if the site should definitely be
	 * deleted, because it's basically irreversible.
	 */
	function fullyDelete() {
		global $IP;

		if ( ! $this->delete_this ) return;

		$db = WGUtils::getMainDBForWriting();
		// save deletion to action_history table
		$query = "INSERT INTO action_history (site_id, site_url, action) VALUES ({$this->id}, '{$this->url}', 'Deleted')";
		$db->query( $query );
		// delete from site_settings table
		$query2 = "DELETE FROM site_settings WHERE id = {$this->id}";
		$db->query( $query2 );
		// delete database
		$query3 = "DROP DATABASE IF EXISTS `{$this->db_name}`";
		$db->query( $query3 );
		// delete all images, and return the number deleted
		$num_deleted_files = 0;

		$images_dir = $IP . "/images/" . $this->url;
		$num_deleted_files += self::rmdir_recursive( $images_dir );
		$logo_dir = $IP . "/skins/common/images/logos/" . $this->url;
		$num_deleted_files += self::rmdir_recursive( $logo_dir );
		$favicon_dir = $IP . "/skins/common/images/favicon/" . $this->url;
		$num_deleted_files += self::rmdir_recursive( $favicon_dir );


		// Delete any other files or data associated with this site
		//wfRunHooks ( 'WikiGardenDeleteSite' );

		return $num_deleted_files;
	}
}
