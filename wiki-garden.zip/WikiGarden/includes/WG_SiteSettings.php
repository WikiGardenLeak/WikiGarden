<?php

/**
 * WGSiteSettings - holds static functions of the Wiki Garden extension called
 * by hooks in the Site Settings extension.
 *
 * @author Yaron Koren
 */
class WGSiteSettings {

	public static function turnOffSSDBCreation( &$continueWithUpdate ) {
		global $wgDBname, $wgWikiGardenMainDB;
		if ( $wgDBname != $wgWikiGardenMainDB ) {
			$continueWithUpdate = false;
		}
		return true;
	}

	public static function describeDBSchema( $updater ) {
		global $wgDBname, $wgWikiGardenMainDB;
		$dir = dirname( __FILE__ );

		// DB updates
		// This should hopefully only get called for the main
		// database.
		if ( $wgDBname == $wgWikiGardenMainDB ) {
			$updater->addExtensionUpdate( array( 'updateTable', 'site_settings', "$dir/../WikiGarden.sql", true ) );
		}
		return true;
	}

	public static function createImagesDirectory( $siteSettings, &$fieldsAndStartingValues ) {
		global $IP;

		// Create images directory - this isn't really necessary, since
		// it will get created anyway when the first file is uploaded.
		$images_dir = "$IP/images/" . $siteSettings->getImagesSubirectoryName();
		// Check if directory already exists, in case a wiki
		// at this URL existed and was then deleted.
		if ( ! file_exists( $images_dir ) ) {
			mkdir( $images_dir );
		}
		return true;
	}

	public static function addSiteSettingsFields( &$allFields ) {
		global $wgWikiGardenServiceSettings;

		$starting_service_level = key( $wgWikiGardenServiceSettings );
		$allFields['main']['url_alias'] = array( false, null );
		$allFields['preset'] = array(
			'id' => array( false, null ),
			'url' => array( false, null ),
			'owner_id' => array( false, null ),
			'db_name' => array( false, null ),
			'created_at' => array( false, null ),
		);
		$allFields['service level'] = array(
			'service_level' => array( false, $starting_service_level )
		);
		$allFields['deletion'] = array(
			'delete_this' => array( true, false ),
		);
		$allFields['admin-only'] = array(
			'virtual_domain' => array( false, null ),
			'custom_skin' => array( false, null )
		);
		return true;
	}

	public static function setupBeforeLoadSettings() {
		global $wgScriptPath, $wgWikiGardenIsURLAlias;

		// New global variable, for use by the (patched) wfScript() function in GlobalFunctions.php.
		global $wgScriptPathReal;
		$wgScriptPathReal = $wgScriptPath;
		if ( $wgWikiGardenIsURLAlias ) {
			global $wgWikiGardenDomain, $wgScriptPath;
			$domain = "http://" . SSStore::getValue( 'url' ) . '.' . $wgWikiGardenDomain;
			$wgScriptPath = $domain . $wgScriptPath;
		}
		return true;
	}

	public static function loadSettings( $siteSettings ) {
		global $wgDBname, $wgLogo, $wgFavicon;

		$wgDBname = $siteSettings->db_name;
		$db = wfGetDB( DB_SLAVE );
		$db_selected = $db->selectDB( $wgDBname );
		if ( !$db_selected ) {
			die( "Error: database '$wgDBname' not found for this wiki." );
		}

		if ( is_null( $wgLogo) && ! WGUtils::currentSiteIsMainSite() ) {
			global $wgWikiGardenDefaultLogo;
			$wgLogo = $wgWikiGardenDefaultLogo;
		}
		if ( is_null( $wgFavicon ) && ! WGUtils::currentSiteIsMainSite() ) {
			$wgFavicon = "/favicon.ico";
		}
		return true;
	}

	// @TODO - move this to WGSite, or WGUtils?
	public static function getMegabytesUsedForSite( $siteSubdomain ) {
		global $IP;
		$upload_dir = $IP . "/images/" . $siteSubdomain;
		if ( file_exists( $upload_dir ) ) {
			$du = array();
			exec( "du -s --block-size=1K $upload_dir", $du );
			list( $total_kb_used, $dir ) = explode( "\t", $du[0] );
			// don't count the usage in the 'deleted' directory
			$deleted_dir = "$upload_dir/deleted";
			if ( file_exists( $deleted_dir ) ) {
				$du = array();
				exec( "du -s --block-size=1K $deleted_dir", $du );
				list( $kb_used_in_deleted, $dir ) = explode( "\t", $du[0] );
				return ( $total_kb_used - $kb_used_in_deleted ) / 1024;
			} else {
				return $total_kb_used / 1024;
			}
		} else {
			return 0;
		}
	}

	public static function getServiceLevelSetting( $key ) {
		global $wgWikiGardenServiceSettings;
		$service_level = SSStore::getValue( 'service_level' );
		return $wgWikiGardenServiceSettings[$service_level][$key];
	}

	public static function getMegabytesAllowed() {
		return self::getServiceLevelSetting( 'disk megabytes' );
	}

	public static function getServiceLevelName() {
		return self::getServiceLevelSetting( 'name' );
	}

	public static function getServiceLevelShortName() {
		return self::getServiceLevelSetting( 'short name' );
	}

	public static function requiresSubscription() {
		return ( self::getServiceLevelSetting( 'monthly rate' ) > 0 );
	}

	public static function canBePrivate() {
		return self::getServiceLevelSetting( 'private allowed' );
	}

	public static function canHaveAds() {
		return self::getServiceLevelSetting( 'ads allowed' );
	}

	public static function canHaveFavicon() {
		return self::getServiceLevelSetting( 'favicon allowed' );
	}

	public static function canHaveVirtualDomain() {
		return self::getServiceLevelSetting( 'virtual domain allowed' );
	}

	public static function possiblyDisallowPrivacyOption( $privacyType, $option, &$attrs, &$option_text ) {
		if ( $privacyType == 'viewing_policy_id' && !self::canBePrivate() && $option->getID() != 1 ) {
			$attrs['disabled'] = true;
			$option_text = '<span style="color:#999999">' . $option_text . '</span>';
		}
		return true;
	}

	public static function possiblyDisplayPrivacyOptionsFooter( $privacyType, &$text ) {
		if ( $privacyType == 'viewing_policy_id' && ! self::canBePrivate() ) {
			$text .= "<p><em>" . wfMessage( 'wg_sitesettings_privateforbidden' )->text() . "</em></p>\n";
		}
		return true;
	}

	public static function possiblyDisableFaviconInput( $siteSettings, &$text ) {
		if ( ! self::canHaveFavicon() ) {
			$text =<<<END
	<h2>Favicon file</h2>

END;
			$text .= "<p style=\"padding-left: 15px\"><em>" . wfMessage('wg_sitesettings_fieldforbidden', 'basic (free) or premium')->text() . "</em></p>\n";
		}
		return true;
	}

	public static function possiblyDisallowPrivateSite( $siteSettings, &$text ) {
		if ( !self::canBePrivate() ) {
			$text = 'public';
		}
		return true;
	}

	public static function addIDCondition( &$conds ) {
		$conds['id'] = SSStore::getValue( 'id' );
		return true;
	}

	public static function addURLCondition( &$conds ) {
		global $wgWikiGardenSubdomain;
		$conds['url'] = $wgWikiGardenSubdomain;
		return true;
	}

	public static function printSubdomainAliasInput( $siteSettings, &$text ) {
		global $wgWikiGardenDomain;
		$url_alias_input = wfMessage( 'wg_sitesettings_urlaliasinput',
			"\n\t" . '<input type="text" name="url_alias" value="' . $siteSettings->url_alias . '" size="15"/>.' . $wgWikiGardenDomain,
			"{$siteSettings->url}.$wgWikiGardenDomain" )->text();
		$text .= "\t<p>$url_alias_input</p>\n";
		return true;
	}

	public static function printServiceLevelTab( &$pageText, $site ) {
		global $wgUser;
		$skin = $wgUser->getSkin();
		$sl = SpecialPageFactory::getPage('ServiceLevel');
		$service_level_link = $skin->link( $sl->getTitle(), "click here" );
		if ( class_exists( 'SSStore' ) ) {
			$service_level_name = SSStore::getValue( 'service_level' );
		} else {
			$service_level_name = $site->getServiceLevelName();
		}
		$text = "\t<p>" . wfMessage( 'wg_sitesettings_changeservicelevel', $service_level_name, $service_level_link )->text() . "</p>\n";

//		if ( class_exists( 'SSStore' ) ) {
		$megabytes_used = SSStore::getValue( 'megabytesUsed' );
		$megabytes_allowed = SSStore::getValue( 'megabytesAllowed' );
		$canHaveVirtualDomain = SSStore::getValue( 'canHaveVirtualDomain' );
//		} else {
//			$megabytes_used = $site->getMegabytesUsed();
//			$megabytes_allowed = $site->getMegabytesAllowed();
//			$canHaveVirtualDomain = $site->canHaveVirtualDomain();
//		}
		$text .= "\t<p>" . wfMessage( 'wg_sitesettings_alloweddiskspace', number_format( $megabytes_allowed ), number_format( $megabytes_used, 1 ) )->text() . "</p>\n";

		if ( $canHaveVirtualDomain ) {
			global $wgWikiGardenSupportEmail, $wgWikiGardenSitename;
			if ( $site->virtual_domain == '' ) {
				$text .= Html::element( 'p', null, wfMessage( 'wg_sitesettings_requestvirtualdomain', $wgWikiGardenSupportEmail, $wgWikiGardenSitename )->text() ) . "\n";
			} else {
				$text .= "<p>You currently have the ability to have a virtual domain for this site from the URL <a href=\"http://{$site->virtual_domain}\">{$site->virtual_domain}</a>. To change this URL or get rid of it altogether, please write to $wgWikiGardenSupportEmail.</p>\n";
			}
		}
		$pageText .= SpecialSiteSettings::printTab( wfMessage( 'wg_sitesettings_servicelevel' )->text(), $text, "servicelevel" );
		return true;
	}

	public static function printDeletionTab( &$pageText, $site ) {
		$text = "";

		if ( ! $site->delete_this ) {
			$text .= '<p>' . wfMessage( 'wg_sitesettings_deletion_docu' )->text() . "</p>\n";
			$text .= Html::input(
				'delete',
				wfMessage( 'wg_sitesettings_deletesite' )->text(), 
				'submit'
			) . "\n";
		} else {
			$text .= Html::element( 'p', null, wfMessage( 'wg_managesite_willbedeleted' )->text() ) . "\n";
			$text .= Html::input(
				'undelete',
				wfMessage( 'wg_sitedeletion_undorequest' )->text(),
				'submit'
			) . "\n";
		}

		$pageText .= SpecialSiteSettings::printTab( wfMessage( 'wg_sitesettings_deletion' )->text(), $text, "deletion" );
		return true;
	}

	public static function checkTabSettingsBeforeSaving( $tabName, &$valuesToUpdate, &$errorMessage ) {
		if ( $tabName == 'main' ) {
			$urlAlias = $valuesToUpdate['url_alias'];
			$id = SSStore::getValue( 'id' );
			if ( empty( $urlAlias ) ) {
				$valuesToUpdate['url_alias'] = null;
			} else {
				// Make sure this URL alias hasn't already been
				// taken by someone else.
				$db = SSUtils::getDBForReading();
				$row = $db->selectRow( 'site_settings', 'url',
					"id != $id AND (url = '$urlAlias' OR url_alias = '$urlAlias')"
				);
				if ( ! empty( $row ) ) {
					$errorMessage = "'$urlAlias' cannot be used as a URL alias because it has already been taken.";
				}
			}
		} elseif ( $tabName == 'deletion' ) {
			die("Site deletion/undeletion is currently undergoing maintenance - please check back in a few minutes.");
		}
		return true;
	}

	public static function updateDeletionState( &$siteSettings, &$text ) {
		global $wgRequest;

		if ( $wgRequest->getCheck( 'delete' ) ) {
			$siteSettings->delete_this = true;
		} elseif ( $wgRequest->getCheck( 'undelete' ) ) {
			$siteSettings->delete_this = false;
		} else {
			return true;
		}

		$valuesToUpdate = array();
		$valuesToUpdate['delete_this'] = $siteSettings->delete_this;
		SSUtils::saveSiteValuesToDB( $valuesToUpdate );

		return true;
	}

	public static function setImagesSubdirectoryName( $siteSettings, &$imagesSubdirectory ) {
		global $wgWikiGardenSubdomain;
		$imagesSubdirectory = $wgWikiGardenSubdomain;
		return true;
	}

}
