<?php

/**
 * WGUtils - holds static functions, mostly called from hooks in core
 * MediaWiki.
 *
 * @author Yaron Koren
 */
class WGUtils {

	static function currentSiteIsMainSite() {
		global $wgWikiGardenSubdomain, $wgWikiGardenMainSubdomains;
		return in_array( $wgWikiGardenSubdomain, $wgWikiGardenMainSubdomains );
	}

	static function initializeSite() {
		global $wgWikiGardenDBNamePrefix, $wgWikiGardenSubdomain, $wgDBname;

		// The next five lines are necessary to handle user login,
		// among other things.
		$dbr = wfGetDB( DB_MASTER );
		$wgDBname = $wgWikiGardenDBNamePrefix . $wgWikiGardenSubdomain;
		if ( $dbr->selectDB( $wgDBname ) ) {
			$dbr->query( "USE `$wgDBname`" );
		}

		if ( is_null( $wgWikiGardenSubdomain ) ) {
			// No site found for this URL - load the settings
			// for the first 'main' subdomain, to avoid database
			// errors later, and set the output to be a standard
			// 404 error.
			global $wgWikiGardenMainSubdomains;
			$main_site = WGSite::findByURL( $wgWikiGardenMainSubdomains[0] );
			$main_site->loadSettings();
			WGUtils::print404Error();
			return;
		}

		$site = WGSite::findByURL( $wgWikiGardenSubdomain );
		if ( ! is_null( $site ) ) {
			$site->loadSettings();
		} else {
			$site = new WGSite();
		}
		global $wgWikiGardenCurrentSite;
		$wgWikiGardenCurrentSite = $site;
	}

	static function selectMainDB( &$db ) {
		global $wgWikiGardenMainDB;
		$db->selectDB( $wgWikiGardenMainDB );
	}

	static function setUser( $user, $s ) {
		if ( self::currentSiteIsMainSite() ) return true;
		$dbr = wfGetDB( DB_SLAVE );
		// Just overwrite whatever was there before.
		$s = $dbr->selectRow( 'user', '*', array( 'user_id' => $user->mId ), __METHOD__ );
		return true;
	}

	/**
	 * Add user to database - based heavily on MW's
	 * SpecialUserlogin::initUser()
	 */
	public static function createAdminUser( $username, $password, $email ) {
		global $wgWikiGardenAdminDefaultGroups;

		$user = User::newFromName( $username );
		$user->addToDatabase();
		$user->setPassword( $password );
		$user->setEmail( $email );
		$user->confirmEmail();
		$user->setToken();
		$user->saveSettings();

		// add user to all the default groups for admins
		foreach ( $wgWikiGardenAdminDefaultGroups as $group_name ) {
			$user->addGroup( $group_name );
		}

		// "log" user in
		global $wgUser;
		$wgUser = $user;
	}

	public static function getMainDBForReading() {
		global $wgWikiGardenMainDB;
		$db = wfGetDB( DB_SLAVE );
		$db->selectDB( $wgWikiGardenMainDB );
		return $db;
	}

	public static function getMainDBForWriting() {
		global $wgWikiGardenMainDB;
		$db = wfGetDB( DB_MASTER );
		$db->selectDB( $wgWikiGardenMainDB );
		return $db;
	}

	public static function checkUploadQuota( $destName, $tempPath, &$error ) {
		global $wgWikiGardenCurrentSite;

		// TODO get this working!
		//$mb_in_file = $upload_form->getSize() / 1000000;
		$mb_in_file = 0;
		$megabytes_used = $wgWikiGardenCurrentSite->getMegabytesUsed();
		$allowed_megabytes = $wgWikiGardenCurrentSite->getMegabytesAllowed();
		if ( $megabytes_used + $mb_in_file > $allowed_megabytes ) {
			$error .= wfMessage( 'wikigarden_uploadexceedsquota', $megabytes_used, $allowed_megabytes )->text();
			return false;
		}
		return true;
	}

	public static function addPersonalURLs( &$personal_urls, &$title ) {
		global $wgWikiGardenSubdomain, $wgUser;

		$my_sites_vals = null;
		$cur_url = $title->getLocalURL();

		// If it's a main site, and user is allowed to create sites,
		// add a "My sites" link.
		if ( self::currentSiteIsMainSite() ) {
			if (! $wgUser->isAnon() && $wgUser->isAllowed( 'createsite' ) ) {
				$us = SpecialPage::getTitleFor( 'UserSites' );
				$href = $us->getLocalURL();
				$my_sites_vals = array(
					'text' => wfMessage( 'wikigarden_mysites' )->text(),
					'href' => $href,
					'active' => ( $href == $cur_url )
				);
			}
		}

		if ( $my_sites_vals != null ) {
			// Find the location of the 'my preferences' link,
			// and add our links right before it.
			// this is a "key-safe" splice - it preserves both the
			// keys and the values of the array, by editing them
			// separately and then rebuilding the array.
			// based on the example at http://us2.php.net/manual/en/function.array-splice.php#31234
			$tab_keys = array_keys( $personal_urls );
			$tab_values = array_values( $personal_urls );
			$prefs_location = array_search( 'preferences', $tab_keys );
			// If this didn't work for whatever reason, set the
			// location index to -1, so the link shows up at the end.
			if ( $prefs_location == NULL ) {
				$prefs_location = -1;
			}
			if ( $my_sites_vals != null ) {
				array_splice( $tab_keys, $prefs_location, 0, 'mysites' );
				array_splice( $tab_values, $prefs_location, 0, array( $my_sites_vals ) );
				$prefs_location++;
			}
			$personal_urls = array();
			for ( $i = 0; $i < count( $tab_keys ); $i++ ) {
				$personal_urls[$tab_keys[$i]] = $tab_values[$i];
			}
		}
		return true;
	}

	/*
	 * For private sites, if user is blocked from editing, block them from
	 * reading as well.
	 */
	static function blockFromReading( $user, &$rights ) {
		global $wgGroupPermissions;
		if ( $wgGroupPermissions['*']['read'] == false ) {
			if ( $user->isBlocked() ) {
				foreach ( $rights as $i => $right ) {
					if ( $right == 'read' ) {
						unset( $rights[$i] );
						break;
					}
				}
			}
		}
		return true;
	}

	static function addToAdminLinks( &$admin_links_tree ) {
		global $wgUser;

		$general_section = $admin_links_tree->getSection( wfMessage( 'adminlinks_general' )->text() );
		$main_row = $general_section->getRow( 'main' );
		$edit_robots_link = ALItem::newFromEditLink( 'Robots.txt', wfMessage( 'wg_adminlinks_editrobotstxt' )->text() );
		$edit_robots_link->text .= ' (<a href="/robots.txt">view</a>)';
		$main_row->addItem( $edit_robots_link );

		// Add "super-admin" links if user is an administrator,
		// and this is one of the main sites.
		if ( $wgUser->isAllowed( 'administerwikis' ) && WGUtils::currentSiteIsMainSite() ) {
			global $wgSitename;
			$admin_section = new ALSection( wfMessage( 'wg_adminlinks_administration', $wgSitename )->text() );
			$superAdminRow = new ALRow( 'super-admin' );
			$superAdminRow->addItem( ALItem::newFromSpecialPage( 'SiteList' ) );
			$superAdminRow->addItem( ALItem::newFromSpecialPage( 'EditStats' ) );
			$superAdminRow->addItem( ALItem::newFromSpecialPage( 'EmailAdmins' ) );
			$superAdminRow->addItem( ALItem::newFromSpecialPage( 'DeleteOldSites' ) );
			$admin_section->addRow( $superAdminRow );
			$admin_section = $admin_links_tree->addSection( $admin_section, wfMessage( 'adminlinks_general' )->text() );
		}

		return true;
	}

	static function getCurrentSiteURL() {
		global $wgWikiGardenCurrentSite, $wgWikiGardenDomain;
		return "http://{$wgWikiGardenCurrentSite->url}." . $wgWikiGardenDomain;
	}

	/**
	 * Function for File: pages
	 */
	static function handleURLAliasImages( &$imagePage ) {
		global $wgWikiGardenIsURLAlias;
		if ( $wgWikiGardenIsURLAlias ) {
			$domain = self::getCurrentSiteURL();
			$img = $imagePage->getDisplayedFile();
			$img->setUrl( $domain . $img->getUrl() );
			$img->repo->url = $domain . $img->repo->url;
			$imagePage->setFile( $img );
		}
		return true;
	}

	/**
	 * Function for inclusion of files/images in regular pages
	 */
	static function handleURLAliasImages2( $linker, $title, &$file ) {
		global $wgWikiGardenIsURLAlias;
		if ( $wgWikiGardenIsURLAlias && !empty( $file ) && strpos( $file->getUrl(), 'http' ) !== 0 ) {
			$file->setUrl( self::getCurrentSiteURL() . $file->getUrl() );
		}
		return true;
	}

	static function handleURLAliasThumbs( $linker, $title, &$file ) {
		global $wgWikiGardenIsURLAlias;
		if ( $wgWikiGardenIsURLAlias && !empty( $file ) && strpos( $file->getUrl(), 'http' ) !== 0 ) {
			$file->url = self::getCurrentSiteURL() . $file->getUrl();
		}
		return true;
	}

	static function handleURLAliasThumbs2( &$path ) {
		global $wgWikiGardenIsURLAlias;
		if ( $wgWikiGardenIsURLAlias ) {
			$path = self::getCurrentSiteURL() . $path;
		}
		return true;
	}

	static function createDatabase() {
		global $IP, $wgDBname, $wgExtensionMessagesFiles;

		$db = wfGetDB( DB_MASTER );
		$db->query( "CREATE DATABASE IF NOT EXISTS `{$wgDBname}`" );
		$db->selectDB( $wgDBname );
		$db->sourceFile( $IP . '/maintenance/tables.sql' );
		// Calling DatabaseUpdater::doUpdates() prints text to the
		// screen for every (?) DB table - to avoid that, we use
		// ob_start() and ob_end_clean() - as well as turning off
		// the display of warnings and notices, to avoid printing the
		// "Cannot modify header information" warning (which shows
		// up even if ob_end_clean() is called).
		error_reporting( E_ERROR );
		ob_start();
		$updater = DatabaseUpdater::newForDb( $db );
		$updater->doUpdates( array( 'extensions' ) );
		ob_end_clean();

		wfRunHooks( 'WikiGardenCreateDatabase', array( &$db ) );
	}

	public static function print404Error() {
		global $wgOut, $wgSitename, $wgWikiGardenDomain;

		$wgOut->disable();
		header( "HTTP/1.0 404 Not Found" );
		$errorMsg = wfMessage( 'wikigarden-404' )->text();
		print <<<END
<html>
<style type="text/css">
body {
	background: #ffffff;
	font-family: "Lucida Sans Unicode","Lucida Grande",Verdana,Helvetica,Arial,sans-serif;
	text-align: center;
}
</style>
<head><title>$wgSitename: $errorMsg</title></head>
<body>
<h1>$errorMsg</h1>
<p>No site was found at $wgSitename by this name.</p>
<p><a href="http://$wgWikiGardenDomain">Back to $wgSitename</a></p>
</body>
</html>
END;
	}

	// The first argument is passed in locally; the second and third
	// are passed in by the MW hook-handling code.
/*
	public static function googleAnalyticsScript( $account_id, $obj, &$bottomScriptText ) {
		// account ID can end with "-1" or "-2"; if it's not there,
		// add in a "-1"
		if ( ! preg_match( '/-\d\z/', $account_id ) ) {
			$account_id .= "-1";
		}
		$bottomScriptText .=<<<END
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("$account_id");
pageTracker._trackPageview();
</script>

END;
		return true;
	}
*/
}
