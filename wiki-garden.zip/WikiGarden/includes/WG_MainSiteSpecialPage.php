<?php
/**
 *
 * @author Yaron Koren
 */

class WGMainSiteSpecialPage extends SpecialPage {

	/**
	 * Constructor
	 */
	function __construct( $page_name ) {
		parent::__construct( $page_name );
	}

	function execute( $query ) {
		global $wgOut, $wgWikiGardenSitename, $wgWikiGardenDomain;

		$this->setHeaders();

		// Add CSS
		$wgOut->addModules( 'ext.wikigarden.main' );

		// This must be a main site.
		if ( !WGUtils::currentSiteIsMainSite() ) {
			$wgOut->setPageTitle( wfMsg( 'wg_mainsiteonly' ) );
			// @TODO fix this
			$mainURL = "http://$wgWikiGardenDomain";
			$wgOut->addHtml( Html::element( 'p', null, wfMessage( 'wg_mainsiteonlydesc', $wgWikiGardenSitename, $mainURL )->text() ) );
			return;
		}

		$this->printPage( $query );
	}
}
