--
-- SQL for tables needed to run Wiki Garden, in the main database -
-- 'site_settings' and 'action_history'
--

--
-- Additions for table `site_settings`
--

ALTER TABLE `site_settings` ADD (
	`id` int(11) NOT NULL auto_increment,
	`url` varchar(50) NOT NULL,
	`url_alias` varchar(50) default NULL,
	`name` varchar(100) NOT NULL,
	`referring_site` varchar(10) NOT NULL,
	`owner_id` int(11) NOT NULL,
	`created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
	`db_name` varchar(50) NOT NULL,
	`namespace` varchar(50) NOT NULL,
	`copyright_text` varchar(400) NOT NULL,
	`copyright_url` varchar(150) NOT NULL,
	`logo_file` varchar(100) default NULL,
	`favicon_file` varchar(50) default NULL,
	`privacy_level_id` int(11) NOT NULL,
	`registration_policy_id` int(11) NOT NULL,
	`editing_policy_id` int(11) NOT NULL,
	`virtual_domain` varchar(50) default NULL,
	`custom_skin` varchar(30) default NULL,
	`disable_caching` tinyint(1) NOT NULL default '0',
	`delete_this` tinyint(1) NOT NULL,
);

--
-- Table structure for table `action_history`
--

CREATE TABLE IF NOT EXISTS `action_history` (
	`id` int(11) NOT NULL auto_increment,
	`created_at` timestamp NOT NULL default CURRENT_TIMESTAMP,
	`site_id` int(11) NOT NULL,
	`site_url` varchar(100) NOT NULL,
	`action` varchar(100) NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ;
