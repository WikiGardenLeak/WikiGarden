<?php

/**
 * @author Yaron Koren
 */

$messages = array();

$messages['en'] = array(
	'wikigarden-desc' => "Enables a 'wiki farm'",
	'wikigarden-404' => '404 Error: Page Not Found',
	'wikigarden_uploadexceedsquota' => "You cannot upload this file, because you are currently using $1 MB of file space, and uploading it would exceed the allowed quota for your site ($2 MB).",
	'servicelevel' => 'Service level',
	'wg_servicelevel_paymentdesc' => 'Clicking on a button will send you to PayPal, where you can pay with either a PayPal account or a credit card. $1 will have no record of your financial information; only PayPal will store it. <a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">PayPal\'s own terms and conditions</a> will apply to the transaction. Your new level of service will begin as soon as the first payment is made. You can cancel your subscription at any time.',
	'wg_servicelevel_currentlevel' => 'This site is currently at <strong>$1</strong> level.',
	'wg_servicelevel_review' => 'Review the possible service levels.',
	'wg_servicelevel_optionsheader' => 'To upgrade this site, choose from among the following options:',
	'wg_servicelevel_revieworcancel' => 'To change your service level setting, you must first cancel your existing subscription. <a href="$1">Review or cancel subscription.</a>',

	'wg_mainsiteonly' => 'Main site only',
	'wg_mainsiteonlydesc' => 'This special page is not valid for any $1 sites except the <a href="$2">main one</a>.',
	'wg_emailauthrequired' => 'Email authentication required',
	'wg_emailauthrequireddesc' => 'You must have your email address set, and have it be authenticated, to create sites on $1.',

	'createsite' => 'Create a site',
	'wg-createsite-anontext' => 'You must $1 to create a site.',
	'wg-createsite-sitename' => 'Site name:',
	'wg-createsite-url' => 'URL:',
	'wg-createsite-logininformation' => 'Your login information for this new site',
	'wg-createsite-username' => 'Username:',
	'wg-createsite-password' => 'Password:',
	'wg-createsite-errors' => 'There were errors with your submission; see below.',
	'wg-createsite-shortsubdomainerror' => 'The subdomain in the URL must be at least 3 characters long.',
	'wg-createsite-urlinvalidcharserror' => 'URL contains invalid characters - only letters, numbers and dashes are allowed.',
	'wg-createsite-urltakenerror' => 'This URL has already been taken.',
	'wg-createsite-blanksitenameerror' => 'Site name cannot be blank.',
	'wg-createsite-blankusernameerror' => 'Username cannot be blank',
	'wg-createsite-shortpassworderror' => 'Password must be at least 5 characters long',
	'wg-createsite-sitecreated' => 'Your new site, \'$1\', has been created. [$2 Proceed to site]. (You will have to log in there with your new account.)',

	'usersites' => 'User sites',
	'wikigarden_mysites' => 'My sites',
	'wg_usersites_nosites' => 'You do not currently run any sites.',
	'wg_usersites_docu' => 'You run the following sites:',

	'wg_sitesettings_urlaliasinput' => '(Optional) Display site at $1 instead of $2',

	'wg_sitesettings_fieldforbidden' => 'You cannot set this field because you have only a $1 level of service.',
	'wg_sitesettings_privateforbidden' => 'You cannot set this site to be private because you have only a basic (free) level of service.',
	'wg_sitesettings_servicelevel' => 'Service level',
	'wg_sitesettings_changeservicelevel' => 'This site has the <strong>$1</strong> level of service. To change your service level, $2.',
	'wg_sitesettings_alloweddiskspace' => 'You are allowed to use $1 MB of disk space for file uploads on this site. You are currently using $2 MB.',
	'wg_sitesettings_requestvirtualdomain' => 'Because of your service level, you can choose to display your wiki from an outside URL. To do this, write to $1 with the subject line \"Virtual domain\" and specify the URL you would like to point to your $2 wiki.',
	'wg_sitesettings_deletion' => 'Deletion',

	'wg_adminlinks_administration' => '$1 administration',
	'wg_adminlinks_editrobotstxt' => 'Edit robots.txt file',

	'wg_sitesettings_deletion_docu' => 'To request that this site be deleted, hit the button below; it will then be deleted in the next few days, unless you cancel the request.',
	'wg_sitesettings_deletesite' => 'Delete site',
	'wg_sitedeletion_requestmade' => 'You have requested for this site to be deleted. It will be deleted in the next few days, unless you cancel this request.',
	'wg_sitedeletion_undorequest' => 'Undo deletion request',
	'wg_sitedeletion_requestundone' => 'You have undone your request to delete this site. It will not be deleted.',

	'managesite' => 'Manage site',
	'wg_managesite_willbedeleted' => 'This site is set to be deleted.',
	'wg_managesite_virtualdomain' => 'Virtual domain:',
	'wg_managesite_customskin' => 'Custom skin:',

	'sitelist' => 'Site list',
	'wg-sitelist-numsites' => 'There are a total of $1 wikis on $2.',
	'wg_sitelist_sitename' => 'Name',
	'wg_sitelist_owner' => 'Owner',
	'wg_sitelist_datecreated' => 'Date created',
	'wg_sitelist_lastupdated' => 'Last updated',
	'wg_sitelist_numviews' => '# views',

	'deleteoldsites' => 'Mark old sites for deletion',
	'editstats' => 'Editing statistics',
	'wg_editstats_month' => 'Month',
	'wg_editstats_graph' => 'Graph',
	'wg_editstats_numedits' => '# edits',
	'emailadmins' => 'Email site administrators',
	'wg_emailadmins_siteadmins' => '$1 administrators',
	'robots' => 'Robots file',
	'robots.txt' => ' # Lines here will be added to the global robots.txt',
);
